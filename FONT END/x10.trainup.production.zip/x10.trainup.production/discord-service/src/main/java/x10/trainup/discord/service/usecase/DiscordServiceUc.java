package x10.trainup.discord.service.usecase;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import x10.trainup.commons.domain.entities.OrderEntity;
import x10.trainup.commons.domain.entities.OrderItemEntity;
import x10.trainup.commons.domain.entities.ShippingAddressEntity;
import x10.trainup.discord.service.config.DiscordConfig;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class DiscordServiceUc {

    private final RestTemplate restTemplate;
    private final DiscordConfig discordConfig;

    /**
     * Gọi hàm này sau khi tạo / lưu đơn hàng thành công
     */
    public void sendNewOrderMessage(OrderEntity order) {
        if (order == null) {
            return;
        }

        ShippingAddressEntity addr = order.getShippingAddress();
        List<OrderItemEntity> items = order.getItems();

        StringBuilder itemsText = new StringBuilder();
        if (items != null) {
            for (OrderItemEntity item : items) {
                itemsText.append("- ")
                        .append(item.getProductName())
                        .append(" | Màu sắc : ").append(item.getColorName())
                        .append(" | Dung Lượng: ").append(item.getSizeName())
                        .append(" | SL: ").append(item.getQuantity())
                        .append(" | Thành tiền: ")
                        .append(formatMoney(item.getSubtotal()))
                        .append(" đ\n");
            }
        }

        String description =
                "📦 Mã đơn: " + safe(order.getOrderNumber()) + "\n" +
                        "📋 Trạng thái: " + safe(String.valueOf(order.getStatus())) + "\n" +
                        "💳 Thanh toán: " + safe(String.valueOf(order.getPaymentMethod())) +
                        " (" + safe(String.valueOf(order.getPaymentStatus())) + ")\n\n" +

                        "👤 Khách: " + safe(addr != null ? addr.getRecipientName() : "") + "\n" +
                        "📞 SĐT: " + safe(addr != null ? addr.getPhoneNumber() : "") + "\n" +
                        "📍 Địa chỉ: " + safe(addr != null ? addr.getFullAddress() : "") + "\n\n" +

                        "🧾 Sản phẩm:\n" + itemsText + "\n" +

                        "🚚 Phí ship: " + formatMoney(order.getShippingFee()) + " đ\n" +
                        "💰 Tổng thanh toán: " + formatMoney(order.getTotalAmount()) + " đ";

        Map<String, Object> embed = new HashMap<>();
        embed.put("title", "Đơn hàng mới #" + safe(order.getOrderNumber()));
        embed.put("description", description);
        embed.put("color", 5814783); // optional

        Map<String, Object> payload = new HashMap<>();
        payload.put("content", "🛒 Bạn có **đơn hàng mới**!");
        payload.put("embeds", List.of(embed));
        payload.put("tts", true); // 👈 thêm dòng này


        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Map<String, Object>> request = new HttpEntity<>(payload, headers);

        try {
            restTemplate.postForEntity(discordConfig.getWebhookUrl(), request, String.class);
        } catch (Exception e) {
            log.error("❌ Lỗi gửi Discord webhook", e);
        }
    }

    private String safe(String s) {
        return s == null ? "" : s;
    }

    private String formatMoney(BigDecimal value) {
        if (value == null) return "0";
        // toPlainString để không có dạng scientific
        return value.toPlainString();
    }
}
