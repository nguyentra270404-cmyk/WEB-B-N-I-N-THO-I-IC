package x10.trainup.product.core.usecases.increaseStockAndDecreaseSoldUc;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import x10.trainup.commons.domain.entities.ColorVariantEntity;
import x10.trainup.commons.domain.entities.ProductEntity;
import x10.trainup.commons.domain.entities.SizeVariantEntity;
import x10.trainup.commons.exceptions.BusinessException;
import x10.trainup.product.core.errors.ProductError;
import x10.trainup.product.core.repositories.IRepositoryProduct;

import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@AllArgsConstructor
public class IncreaseStockAndDecreaseSoldImpl implements IIncreaseStockAndDecreaseSoldIUc {

    private final IRepositoryProduct iRepositoryProduct;

    @Override
    @Transactional
    public void IncreaseStockAndDecreaseSoldIUc(List<StockUpdateItem> items) {
        log.info("Starting to INCREASE stock and DECREASE sold for {} items (ROLLBACK)", items.size());

        for (StockUpdateItem item : items) {
            log.info("Processing ROLLBACK for item: productId={}, colorId={}, sizeId={}, quantity={}",
                    item.getProductId(), item.getColorId(), item.getSizeId(), item.getQuantity());

            try {
                // 1. Tìm product theo ID
                ProductEntity product = findProduct(item.getProductId());

                // 2. Tìm color variant trong product
                ColorVariantEntity colorVariant = findColorVariant(product, item.getColorId());

                // 3. Tìm size variant trong color
                SizeVariantEntity sizeVariant = findSizeVariant(colorVariant, item.getSizeId());

                int requestedQuantity = item.getQuantity();
                if (requestedQuantity <= 0) {
                    log.error("Invalid rollback quantity: {}", requestedQuantity);
                    throw new BusinessException(
                            ProductError.QUANTITY_INVALID,
                            "Số lượng hoàn lại phải lớn hơn 0"
                    );
                }

                // 4. Lưu giá trị cũ để log
                int oldStock = sizeVariant.getStock();
                int oldSold = sizeVariant.getSold();

                // 5. Tăng stock, giảm sold (rollback)
                sizeVariant.setStock(oldStock + requestedQuantity);

                int newSold = Math.max(0, oldSold - requestedQuantity);
                sizeVariant.setSold(newSold);

                if (oldSold < requestedQuantity) {
                    log.warn("ROLLBACK: Sold ({}) < rollback quantity ({}). Setting sold to 0.",
                            oldSold, requestedQuantity);
                }

                log.info("ROLLBACK completed - Product: {}, Color: {}, Size: {} | Stock: {} -> {}, Sold: {} -> {}",
                        product.getName(),
                        colorVariant.getColorName(),
                        sizeVariant.getSizeName(),
                        oldStock, sizeVariant.getStock(),
                        oldSold, sizeVariant.getSold());

                // 6. Save product
                iRepositoryProduct.save(product);

            } catch (BusinessException e) {
                log.error("BusinessException during rollback: productId={}, colorId={}, sizeId={} - {}",
                        item.getProductId(), item.getColorId(), item.getSizeId(), e.getMessage());
                throw e;
            } catch (Exception e) {
                log.error("Unexpected error during rollback: productId={}, colorId={}, sizeId={}",
                        item.getProductId(), item.getColorId(), item.getSizeId(), e);
                throw new BusinessException(
                        ProductError.INVALID_PRODUCT_DATA,
                        "Lỗi không xác định khi hoàn lại stock: " + e.getMessage()
                );
            }
        }

        log.info("Successfully INCREASED stock and DECREASED sold for all {} items (ROLLBACK COMPLETE)", items.size());
    }

    // ================== FIND METHODS ==================

    private ProductEntity findProduct(String productId) {
        Optional<ProductEntity> productOpt = iRepositoryProduct.findById(productId);

        if (productOpt.isEmpty()) {
            log.error("Product not found during rollback: {}", productId);
            throw new BusinessException(
                    ProductError.PRODUCT_NOT_FOUND,
                    "Không tìm thấy sản phẩm với ID: " + productId
            );
        }
        return productOpt.get();
    }

    private ColorVariantEntity findColorVariant(ProductEntity product, String colorId) {
        if (product.getColors() == null || product.getColors().isEmpty()) {
            log.error("Product {} has no colors", product.getId());
            throw new BusinessException(
                    ProductError.COLOR_NOT_FOUND,
                    "Sản phẩm không có màu nào"
            );
        }

        return product.getColors().stream()
                .filter(c -> c.getId() != null && c.getId().equals(colorId))
                .findFirst()
                .orElseThrow(() -> {
                    log.error("Color {} not found in product {}", colorId, product.getId());
                    return new BusinessException(
                            ProductError.COLOR_NOT_FOUND,
                            String.format("Không tìm thấy màu với ID: %s trong sản phẩm %s (%s)",
                                    colorId, product.getId(), product.getName())
                    );
                });
    }

    private SizeVariantEntity findSizeVariant(ColorVariantEntity colorVariant, String sizeId) {
        if (colorVariant.getSizes() == null || colorVariant.getSizes().isEmpty()) {
            log.error("Color {} has no sizes", colorVariant.getId());
            throw new BusinessException(
                    ProductError.SIZE_NOT_FOUND,
                    "Màu không có size nào"
            );
        }

        return colorVariant.getSizes().stream()
                .filter(s -> s.getId() != null && s.getId().equals(sizeId))
                .findFirst()
                .orElseThrow(() -> {
                    log.error("Size {} not found in color {}", sizeId, colorVariant.getId());
                    return new BusinessException(
                            ProductError.SIZE_NOT_FOUND,
                            String.format("Không tìm thấy size với ID: %s trong màu %s (%s)",
                                    sizeId, colorVariant.getId(), colorVariant.getColorName())
                    );
                });
    }
}
