package x10.trainup.product.core.usecases.increaseStockAndDecreaseSoldUc;


import java.util.List;

public interface IIncreaseStockAndDecreaseSoldIUc {
    void IncreaseStockAndDecreaseSoldIUc(List<StockUpdateItem> items);
}
