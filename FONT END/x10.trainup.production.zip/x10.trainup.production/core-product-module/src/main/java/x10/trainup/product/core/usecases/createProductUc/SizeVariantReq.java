package x10.trainup.product.core.usecases.createProductUc;

import jakarta.validation.constraints.*;
import lombok.*;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SizeVariantReq {

    @NotBlank(message = "Tên size/dung lượng không được để trống")
    private String sizeName; // 128GB, 256GB...

    @NotNull(message = "Giá không được null")
    @DecimalMin(value = "0.0", inclusive = false, message = "Giá phải lớn hơn 0")
    private BigDecimal price;

    @DecimalMin(value = "0.0", inclusive = true, message = "Giá giảm phải >= 0")
    private BigDecimal discountPrice;

    @Min(value = 0, message = "Tồn kho không được âm")
    private int stock;

    @AssertTrue(message = "Giá giảm phải nhỏ hơn hoặc bằng giá gốc")
    public boolean isDiscountValid() {
        if (discountPrice == null || price == null) return true;
        return discountPrice.compareTo(price) <= 0;
    }
}
