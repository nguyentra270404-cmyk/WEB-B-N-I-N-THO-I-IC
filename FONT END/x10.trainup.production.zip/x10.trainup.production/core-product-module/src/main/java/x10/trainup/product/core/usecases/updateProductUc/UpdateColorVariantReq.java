package x10.trainup.product.core.usecases.updateProductUc;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.*;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UpdateColorVariantReq {

    /**
     * ID màu:
     * - Nếu cập nhật màu đã tồn tại -> truyền id.
     * - Nếu thêm màu mới trong update product -> có thể để null, backend tự tạo id.
     */
    private String id;

    @NotBlank(message = "Tên màu không được để trống")
    private String colorName; // Ví dụ: "Đen", "Xanh đậm"

    @NotBlank(message = "Mã màu không được để trống")
    @Pattern(
            regexp = "^#(?:[0-9a-fA-F]{3}){1,2}$",
            message = "Mã màu phải là mã hex hợp lệ, ví dụ: #FF6600"
    )
    private String colorCode;

    @NotBlank(message = "Ảnh chính không được để trống")
    private String mainImage; // path hoặc url tương đối trước khi resolve

    @NotNull(message = "Danh sách ảnh phụ không được null")
    @Size(max = 4, message = "Tối đa 4 ảnh phụ cho mỗi màu")
    private List<@NotBlank(message = "URL ảnh không được để trống") String> imageUrls;

    @NotNull(message = "Danh sách size không được null")
    @NotEmpty(message = "Mỗi màu phải có ít nhất 1 size")
    @Size(max = 5, message = "Tối đa 5 size cho mỗi màu")
    @Valid
    private List<UpdateSizeVariantReq> sizes;
}
