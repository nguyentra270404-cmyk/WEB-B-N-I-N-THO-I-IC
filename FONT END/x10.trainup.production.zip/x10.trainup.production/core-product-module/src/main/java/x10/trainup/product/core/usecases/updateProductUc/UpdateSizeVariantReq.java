package x10.trainup.product.core.usecases.updateProductUc;

import jakarta.validation.constraints.*;
import lombok.*;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UpdateSizeVariantReq {

    /**
     * ID size variant:
     * - Nếu cập nhật size đã tồn tại -> phải gửi id.
     * - Nếu thêm size mới -> id có thể null, backend sẽ generate mới.
     */
    private String id;

    @NotBlank(message = "Tên size/dung lượng không được để trống")
    @Size(min = 1, max = 50, message = "Tên size/dung lượng phải từ 1-50 ký tự")
    private String sizeName; // Ví dụ: 128GB, 256GB, 512GB...

    @NotNull(message = "Giá không được null")
    @DecimalMin(value = "0.0", inclusive = false, message = "Giá phải lớn hơn 0")
    @Digits(integer = 12, fraction = 2, message = "Giá không đúng định dạng")
    private BigDecimal price;

    @DecimalMin(value = "0.0", inclusive = true, message = "Giá giảm phải >= 0")
    @Digits(integer = 12, fraction = 2, message = "Giá giảm không đúng định dạng")
    private BigDecimal discountPrice;

    @Min(value = 0, message = "Tồn kho không được âm")
    private int stock;


    @AssertTrue(message = "Giá giảm phải nhỏ hơn hoặc bằng giá gốc")
    public boolean isDiscountValid() {
        if (discountPrice == null || price == null) return true;
        return discountPrice.compareTo(price) <= 0;
    }
}
