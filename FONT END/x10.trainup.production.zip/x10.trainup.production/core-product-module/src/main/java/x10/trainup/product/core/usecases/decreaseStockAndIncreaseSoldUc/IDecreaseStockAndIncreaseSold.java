package x10.trainup.product.core.usecases.decreaseStockAndIncreaseSoldUc;


import x10.trainup.product.core.usecases.increaseStockAndDecreaseSoldUc.StockUpdateItem;

import java.util.List;

public interface IDecreaseStockAndIncreaseSold {
    void decreaseStockAndIncreaseSold(List<StockUpdateItem> items);
}
