package x10.trainup.product.core.usecases.increaseStockAndDecreaseSoldUc;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StockUpdateItem {

    /**
     * ID sản phẩm – dùng để verify product.
     */
    private String productId;

    /**
     * ID màu của sản phẩm (ColorVariantEntity.id)
     */
    private String colorId;

    /**
     * ID size của màu (SizeVariantEntity.id)
     */
    private String sizeId;

    /**
     * Số lượng cần cập nhật:
     *  - Tăng stock & giảm sold
     *  - Hoặc giảm stock khi bán hàng
     */
    private int quantity;
}
