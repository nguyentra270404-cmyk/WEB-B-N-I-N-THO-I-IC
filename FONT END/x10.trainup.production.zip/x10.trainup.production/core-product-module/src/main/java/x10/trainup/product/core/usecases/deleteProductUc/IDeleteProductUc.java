package x10.trainup.product.core.usecases.deleteProductUc;

public interface IDeleteProductUc {


    void deleteProduct(String productId);
}
