package x10.trainup.product.core.usecases.createProductUc;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import x10.trainup.category.core.repositories.ICategoryReposity;
import x10.trainup.commons.domain.entities.ColorVariantEntity;
import x10.trainup.commons.domain.entities.ProductEntity;
import x10.trainup.commons.domain.entities.SizeVariantEntity;
import x10.trainup.commons.exceptions.BusinessException;
import x10.trainup.commons.util.IMediaUrlResolver;
import x10.trainup.product.core.errors.ProductError;
import x10.trainup.product.core.repositories.IRepositoryProduct;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class CreateProductServerImp implements ICreateProductUc {

    private final IMediaUrlResolver mediaUrlResolver;
    private final IRepositoryProduct repositoryProduct;
    private final ICategoryReposity categoryReposity;

    @Override
    @Transactional
    public ProductEntity process(@Valid @NotNull CreateProductReq req) {
        log.info("🚀 Starting product creation: name={}, brand={}, categoryId={}",
                req.getName(), req.getBrand(), req.getCategoryId());

        try {
            // 1. Validate business
            validateCategory(req.getCategoryId());
            validateProductName(req.getName());
            validateColorVariants(req.getColors());

            // 2. Build entity
            ProductEntity product = buildProductEntity(req);

            // 3. Save DB
            ProductEntity saved = repositoryProduct.save(product);

            log.info("✅ Successfully created product [id={}, name={}, colors={}, totalSizeVariants={}]",
                    saved.getId(),
                    saved.getName(),
                    saved.getColors() != null ? saved.getColors().size() : 0,
                    countTotalSizeVariants(saved.getColors()));

            return saved;

        } catch (BusinessException e) {
            log.error("❌ Business error creating product: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("❌ Unexpected error creating product: name={}", req.getName(), e);
            throw new BusinessException(
                    ProductError.PRODUCT_CREATION_FAILED,
                    "Lỗi không xác định khi tạo sản phẩm: " + e.getMessage()
            );
        }
    }

    // ========================================
    // 🔹 BUILD METHODS
    // ========================================

    private ProductEntity buildProductEntity(CreateProductReq req) {
        Instant now = Instant.now();

        List<ColorVariantEntity> colorEntities = mapColorVariants(req.getColors());

        return ProductEntity.builder()
                .id(generateUUID())
                .name(sanitizeString(req.getName()))
                .description(sanitizeString(req.getDescription()))
                .brand(sanitizeString(req.getBrand()))
                .categoryId(req.getCategoryId())
                .colors(colorEntities)
                .active(true)
                .createdAt(now)
                .updatedAt(now)
                .build();
    }

    private List<ColorVariantEntity> mapColorVariants(List<ColorVariantReq> colorReqs) {
        if (CollectionUtils.isEmpty(colorReqs)) {
            return Collections.emptyList();
        }

        return colorReqs.stream()
                .map(this::buildColorVariantEntity)
                .collect(Collectors.toList());
    }

    private ColorVariantEntity buildColorVariantEntity(ColorVariantReq colorReq) {
        return ColorVariantEntity.builder()
                .id(generateUUID())
                .colorName(sanitizeString(colorReq.getColorName()))
                .colorCode(colorReq.getColorCode() != null ? colorReq.getColorCode().trim() : null)
                .mainImage(resolveImageUrl(colorReq.getMainImage()))
                .imageUrls(resolveImageUrls(colorReq.getImageUrls()))
                .sizes(mapSizeVariants(colorReq.getSizes()))
                .build();
    }

    private List<SizeVariantEntity> mapSizeVariants(List<SizeVariantReq> sizeReqs) {
        if (CollectionUtils.isEmpty(sizeReqs)) {
            return Collections.emptyList();
        }

        return sizeReqs.stream()
                .map(this::buildSizeVariantEntity)
                .collect(Collectors.toList());
    }

    private SizeVariantEntity buildSizeVariantEntity(SizeVariantReq sizeReq) {
        return SizeVariantEntity.builder()
                .id(generateUUID())
                .sizeName(sanitizeString(sizeReq.getSizeName()))
                .price(sizeReq.getPrice())
                .discountPrice(sizeReq.getDiscountPrice())
                .stock(sizeReq.getStock())
                .sold(0) // Mới tạo -> chưa bán gì
                .build();
    }

    // ========================================
    // 🔹 VALIDATION METHODS
    // ========================================

    private void validateCategory(String categoryId) {
        if (categoryId == null || categoryId.isBlank()) {
            throw new BusinessException(ProductError.INVALID_CATEGORY);
        }

        if (!categoryReposity.existsById(categoryId)) {
            log.warn("⚠️ Category not found: categoryId={}", categoryId);
            throw new BusinessException(
                    ProductError.CATEGORY_NOT_FOUND,
                    "Danh mục không tồn tại với ID: " + categoryId
            );
        }
    }

    private void validateProductName(String name) {
        if (name == null || name.isBlank()) {
            throw new BusinessException(ProductError.INVALID_PRODUCT_NAME);
        }

        String sanitizedName = sanitizeString(name);
        boolean exists = repositoryProduct.findByNameContainingIgnoreCase(sanitizedName)
                .stream()
                .anyMatch(p -> p.getName().equalsIgnoreCase(sanitizedName));

        if (exists) {
            log.warn("⚠️ Product name already exists: name={}", sanitizedName);
            throw new BusinessException(
                    ProductError.PRODUCT_ALREADY_EXISTS,
                    "Sản phẩm với tên '" + sanitizedName + "' đã tồn tại"
            );
        }
    }

    private void validateColorVariants(List<ColorVariantReq> colors) {
        if (CollectionUtils.isEmpty(colors)) {
            throw new BusinessException(
                    ProductError.INVALID_SIZE_VARIANTS,
                    "Sản phẩm phải có ít nhất 1 màu"
            );
        }

        // Check trùng tên màu trong cùng 1 product
        long uniqueColorNames = colors.stream()
                .map(ColorVariantReq::getColorName)
                .map(this::sanitizeString)
                .distinct()
                .count();

        if (uniqueColorNames < colors.size()) {
            throw new BusinessException(
                    ProductError.DUPLICATE_SIZE_VARIANTS,
                    "Sản phẩm có màu bị trùng tên"
            );
        }

        // Validate size variants trong từng màu
        colors.forEach(color ->
                validateSizeVariants(color.getColorName(), color.getSizes())
        );
    }

    private void validateSizeVariants(String colorName, List<SizeVariantReq> sizes) {
        if (CollectionUtils.isEmpty(sizes)) {
            throw new BusinessException(
                    ProductError.INVALID_SIZE_VARIANTS,
                    "Màu '" + colorName + "' phải có ít nhất 1 size/dung lượng"
            );
        }

        // Check trùng sizeName trong cùng 1 màu
        long uniqueSizes = sizes.stream()
                .map(SizeVariantReq::getSizeName)
                .map(this::sanitizeString)
                .distinct()
                .count();

        if (uniqueSizes < sizes.size()) {
            throw new BusinessException(
                    ProductError.DUPLICATE_SIZE_VARIANTS,
                    "Màu '" + colorName + "' có size/dung lượng trùng lặp"
            );
        }

        // Validate logic giá cho từng size
        sizes.forEach(this::validatePriceLogic);
    }

    private void validatePriceLogic(SizeVariantReq sizeReq) {
        String sizeName = sanitizeString(sizeReq.getSizeName());

        if (sizeReq.getPrice() == null) {
            throw new BusinessException(
                    ProductError.INVALID_PRICE,
                    "Giá của size '" + sizeName + "' không được null"
            );
        }

        if (sizeReq.getPrice().compareTo(BigDecimal.ZERO) <= 0) {
            throw new BusinessException(
                    ProductError.INVALID_PRICE,
                    "Giá của size '" + sizeName + "' phải lớn hơn 0"
            );
        }

        if (sizeReq.getDiscountPrice() != null) {
            if (sizeReq.getDiscountPrice().compareTo(BigDecimal.ZERO) < 0) {
                throw new BusinessException(
                        ProductError.INVALID_DISCOUNT_PRICE,
                        "Giá giảm của size '" + sizeName + "' phải >= 0"
                );
            }

            if (sizeReq.getDiscountPrice().compareTo(sizeReq.getPrice()) > 0) {
                throw new BusinessException(
                        ProductError.INVALID_DISCOUNT_PRICE,
                        "Giá giảm của size '" + sizeName + "' phải nhỏ hơn hoặc bằng giá gốc"
                );
            }
        }
    }

    // ========================================
    // 🔹 MEDIA URL HANDLING
    // ========================================

    private String resolveImageUrl(String imagePath) {
        if (imagePath == null || imagePath.isBlank()) {
            return null;
        }

        try {
            return mediaUrlResolver.resolvePublicUrl(imagePath.trim());
        } catch (Exception e) {
            log.warn("⚠️ Failed to resolve image URL: path={}, error={}",
                    imagePath, e.getMessage());
            return null;
        }
    }

    private List<String> resolveImageUrls(List<String> imagePaths) {
        if (CollectionUtils.isEmpty(imagePaths)) {
            return Collections.emptyList();
        }

        return imagePaths.stream()
                .filter(path -> path != null && !path.isBlank())
                .map(String::trim)
                .map(this::resolveImageUrl)
                .filter(url -> url != null)
                .collect(Collectors.toList());
    }

    // ========================================
    // 🔹 UTILITY METHODS
    // ========================================

    private String generateUUID() {
        return UUID.randomUUID().toString();
    }

    private String sanitizeString(String input) {
        if (input == null) {
            return null;
        }
        return input.trim();
    }

    private int countTotalSizeVariants(List<ColorVariantEntity> colors) {
        if (CollectionUtils.isEmpty(colors)) {
            return 0;
        }

        return colors.stream()
                .map(ColorVariantEntity::getSizes)
                .filter(sizes -> !CollectionUtils.isEmpty(sizes))
                .mapToInt(List::size)
                .sum();
    }
}
