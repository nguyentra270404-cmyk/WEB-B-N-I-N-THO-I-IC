package x10.trainup.product.core.usecases.updateProductUc;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import x10.trainup.category.core.repositories.ICategoryReposity;
import x10.trainup.commons.domain.entities.ColorVariantEntity;
import x10.trainup.commons.domain.entities.ProductEntity;
import x10.trainup.commons.domain.entities.SizeVariantEntity;
import x10.trainup.commons.exceptions.BusinessException;
import x10.trainup.commons.util.IMediaUrlResolver;
import x10.trainup.product.core.errors.ProductError;
import x10.trainup.product.core.repositories.IRepositoryProduct;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class UpdateProductServiceImp implements IUpdateProductUc {

    private final IMediaUrlResolver mediaUrlResolver;
    private final IRepositoryProduct repositoryProduct;
    private final ICategoryReposity categoryReposity;

    @Override
    @Transactional
    public ProductEntity process(
            @NotBlank String productId,
            @Valid @NotNull UpdateProductReq req) {

        log.info("🔄 Starting product update: id={}, name={}, categoryId={}",
                productId, req.getName(), req.getCategoryId());

        try {
            // 1. Tìm product
            ProductEntity existingProduct = findProductById(productId);

            // 2. Validate nghiệp vụ
            validateCategory(req.getCategoryId());
            validateProductNameForUpdate(productId, req.getName());
            validateColorVariants(req.getColors());

            // 3. Update field + merge colors/sizes
            updateProductFields(existingProduct, req);

            // 4. Save DB
            ProductEntity updated = repositoryProduct.save(existingProduct);

            log.info("✅ Successfully updated product [id={}, name={}, colors={}, totalSizeVariants={}]",
                    updated.getId(),
                    updated.getName(),
                    updated.getColors() != null ? updated.getColors().size() : 0,
                    countTotalSizeVariants(updated.getColors()));

            return updated;

        } catch (BusinessException e) {
            log.error("❌ Business error updating product: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("❌ Unexpected error updating product: id={}", productId, e);
            throw new BusinessException(
                    ProductError.PRODUCT_UPDATE_FAILED,
                    "Lỗi không xác định khi cập nhật sản phẩm: " + e.getMessage()
            );
        }
    }

    // ========================================
    // 🔹 FIND & UPDATE METHODS
    // ========================================

    private ProductEntity findProductById(String productId) {
        return repositoryProduct.findById(productId)
                .orElseThrow(() -> {
                    log.warn("⚠️ Product not found: id={}", productId);
                    return new BusinessException(
                            ProductError.PRODUCT_NOT_FOUND,
                            "Không tìm thấy sản phẩm với ID: " + productId
                    );
                });
    }

    private void updateProductFields(ProductEntity product, UpdateProductReq req) {
        product.setName(sanitizeString(req.getName()));
        product.setDescription(sanitizeString(req.getDescription()));
        product.setBrand(sanitizeString(req.getBrand()));
        product.setCategoryId(req.getCategoryId());

        if (req.getActive() != null) {
            product.setActive(req.getActive());
        }

        // Merge colors + sizes
        List<ColorVariantEntity> mergedColors = mergeColorVariants(
                product.getColors(),
                req.getColors()
        );
        product.setColors(mergedColors);

        product.setUpdatedAt(Instant.now());
    }

    // ========================================
    // 🔹 MERGE LOGIC (COLORS + SIZES)
    // ========================================

    private List<ColorVariantEntity> mergeColorVariants(
            List<ColorVariantEntity> existingColors,
            List<UpdateColorVariantReq> newColorReqs) {

        Map<String, ColorVariantEntity> existingColorMap = new HashMap<>();
        if (!CollectionUtils.isEmpty(existingColors)) {
            existingColorMap = existingColors.stream()
                    .filter(c -> c.getId() != null)
                    .collect(Collectors.toMap(ColorVariantEntity::getId, c -> c));
        }

        List<ColorVariantEntity> merged = new ArrayList<>();

        for (UpdateColorVariantReq colorReq : newColorReqs) {

            if (colorReq.getId() != null && existingColorMap.containsKey(colorReq.getId())) {
                // Update màu cũ
                ColorVariantEntity existing = existingColorMap.get(colorReq.getId());
                updateColorVariantEntity(existing, colorReq);
                merged.add(existing);
            } else {
                // Thêm màu mới
                ColorVariantEntity created = buildNewColorVariantEntity(colorReq);
                merged.add(created);
            }
        }

        // (Business rule đơn giản: màu nào không còn trong req thì xem như bị xoá)

        return merged;
    }

    private void updateColorVariantEntity(ColorVariantEntity existing, UpdateColorVariantReq req) {
        existing.setColorName(sanitizeString(req.getColorName()));
        existing.setColorCode(req.getColorCode() != null ? req.getColorCode().trim() : null);
        existing.setMainImage(resolveImageUrl(req.getMainImage()));
        existing.setImageUrls(resolveImageUrls(req.getImageUrls()));

        List<SizeVariantEntity> mergedSizes = mergeSizeVariants(
                existing.getSizes(),
                req.getSizes()
        );
        existing.setSizes(mergedSizes);
    }

    private ColorVariantEntity buildNewColorVariantEntity(UpdateColorVariantReq req) {
        return ColorVariantEntity.builder()
                .id(generateUUID())
                .colorName(sanitizeString(req.getColorName()))
                .colorCode(req.getColorCode() != null ? req.getColorCode().trim() : null)
                .mainImage(resolveImageUrl(req.getMainImage()))
                .imageUrls(resolveImageUrls(req.getImageUrls()))
                .sizes(buildNewSizeVariants(req.getSizes()))
                .build();
    }

    private List<SizeVariantEntity> mergeSizeVariants(
            List<SizeVariantEntity> existingSizes,
            List<UpdateSizeVariantReq> newSizeReqs) {

        Map<String, SizeVariantEntity> existingSizeMap = new HashMap<>();
        if (!CollectionUtils.isEmpty(existingSizes)) {
            existingSizeMap = existingSizes.stream()
                    .filter(s -> s.getId() != null)
                    .collect(Collectors.toMap(SizeVariantEntity::getId, s -> s));
        }

        List<SizeVariantEntity> merged = new ArrayList<>();

        for (UpdateSizeVariantReq sizeReq : newSizeReqs) {
            if (sizeReq.getId() != null && existingSizeMap.containsKey(sizeReq.getId())) {
                // Update size cũ
                SizeVariantEntity existing = existingSizeMap.get(sizeReq.getId());
                updateSizeVariantEntity(existing, sizeReq);
                merged.add(existing);
            } else {
                // Thêm size mới
                SizeVariantEntity created = buildNewSizeVariantEntity(sizeReq);
                merged.add(created);
            }
        }

        // (Business rule đơn giản: size nào không còn trong req thì coi như xoá)

        return merged;
    }

    private List<SizeVariantEntity> buildNewSizeVariants(List<UpdateSizeVariantReq> sizeReqs) {
        if (CollectionUtils.isEmpty(sizeReqs)) {
            return Collections.emptyList();
        }

        return sizeReqs.stream()
                .map(this::buildNewSizeVariantEntity)
                .collect(Collectors.toList());
    }

    private void updateSizeVariantEntity(SizeVariantEntity existing, UpdateSizeVariantReq req) {
        existing.setSizeName(sanitizeString(req.getSizeName()));
        existing.setPrice(req.getPrice());
        existing.setDiscountPrice(req.getDiscountPrice());
        existing.setStock(req.getStock());
        // ⚠️ Không update sold ở đây – sold thuộc nghiệp vụ bán hàng
    }

    private SizeVariantEntity buildNewSizeVariantEntity(UpdateSizeVariantReq req) {
        return SizeVariantEntity.builder()
                .id(generateUUID())
                .sizeName(sanitizeString(req.getSizeName()))
                .price(req.getPrice())
                .discountPrice(req.getDiscountPrice())
                .stock(req.getStock())
                .sold(0)
                .build();
    }

    // ========================================
    // 🔹 VALIDATION METHODS
    // ========================================

    private void validateCategory(String categoryId) {
        if (categoryId == null || categoryId.isBlank()) {
            throw new BusinessException(ProductError.INVALID_CATEGORY);
        }

        if (!categoryReposity.existsById(categoryId)) {
            log.warn("⚠️ Category not found: categoryId={}", categoryId);
            throw new BusinessException(
                    ProductError.CATEGORY_NOT_FOUND,
                    "Danh mục không tồn tại với ID: " + categoryId
            );
        }
    }

    private void validateProductNameForUpdate(String productId, String newName) {
        if (newName == null || newName.isBlank()) {
            throw new BusinessException(ProductError.INVALID_PRODUCT_NAME);
        }

        String sanitizedName = sanitizeString(newName);

        Optional<ProductEntity> existingProduct = repositoryProduct
                .findByNameContainingIgnoreCase(sanitizedName)
                .stream()
                .filter(p -> p.getName().equalsIgnoreCase(sanitizedName))
                .findFirst();

        if (existingProduct.isPresent() && !existingProduct.get().getId().equals(productId)) {
            log.warn("⚠️ Product name already exists: name={}", sanitizedName);
            throw new BusinessException(
                    ProductError.PRODUCT_ALREADY_EXISTS,
                    "Sản phẩm với tên '" + sanitizedName + "' đã tồn tại"
            );
        }
    }

    private void validateColorVariants(List<UpdateColorVariantReq> colors) {
        if (CollectionUtils.isEmpty(colors)) {
            throw new BusinessException(
                    ProductError.INVALID_SIZE_VARIANTS,
                    "Sản phẩm phải có ít nhất 1 màu"
            );
        }

        // Check trùng tên màu
        long uniqueColorNames = colors.stream()
                .map(UpdateColorVariantReq::getColorName)
                .map(this::sanitizeString)
                .distinct()
                .count();

        if (uniqueColorNames < colors.size()) {
            throw new BusinessException(
                    ProductError.DUPLICATE_SIZE_VARIANTS,
                    "Sản phẩm có màu bị trùng tên"
            );
        }

        // Validate size trong từng màu
        colors.forEach(color ->
                validateSizeVariants(color.getColorName(), color.getSizes())
        );
    }

    private void validateSizeVariants(String colorName, List<UpdateSizeVariantReq> sizes) {
        if (CollectionUtils.isEmpty(sizes)) {
            throw new BusinessException(
                    ProductError.INVALID_SIZE_VARIANTS,
                    "Màu '" + colorName + "' phải có ít nhất 1 size/dung lượng"
            );
        }

        long uniqueSizes = sizes.stream()
                .map(UpdateSizeVariantReq::getSizeName)
                .map(this::sanitizeString)
                .distinct()
                .count();

        if (uniqueSizes < sizes.size()) {
            throw new BusinessException(
                    ProductError.DUPLICATE_SIZE_VARIANTS,
                    "Màu '" + colorName + "' có size/dung lượng trùng lặp"
            );
        }

        sizes.forEach(this::validatePriceLogic);
    }

    private void validatePriceLogic(UpdateSizeVariantReq sizeReq) {
        String sizeName = sanitizeString(sizeReq.getSizeName());

        if (sizeReq.getPrice() == null) {
            throw new BusinessException(
                    ProductError.INVALID_PRICE,
                    "Giá của size '" + sizeName + "' không được null"
            );
        }

        if (sizeReq.getPrice().compareTo(BigDecimal.ZERO) <= 0) {
            throw new BusinessException(
                    ProductError.INVALID_PRICE,
                    "Giá của size '" + sizeName + "' phải lớn hơn 0"
            );
        }

        if (sizeReq.getDiscountPrice() != null) {
            if (sizeReq.getDiscountPrice().compareTo(BigDecimal.ZERO) < 0) {
                throw new BusinessException(
                        ProductError.INVALID_DISCOUNT_PRICE,
                        "Giá giảm của size '" + sizeName + "' phải >= 0"
                );
            }

            if (sizeReq.getDiscountPrice().compareTo(sizeReq.getPrice()) > 0) {
                throw new BusinessException(
                        ProductError.INVALID_DISCOUNT_PRICE,
                        "Giá giảm của size '" + sizeName + "' phải nhỏ hơn hoặc bằng giá gốc"
                );
            }
        }
    }

    // ========================================
    // 🔹 MEDIA URL HANDLING
    // ========================================

    private String resolveImageUrl(String imagePath) {
        if (imagePath == null || imagePath.isBlank()) {
            return null;
        }

        // Nếu đã là URL đầy đủ thì giữ nguyên
        if (imagePath.startsWith("http://") || imagePath.startsWith("https://")) {
            return imagePath.trim();
        }

        try {
            return mediaUrlResolver.resolvePublicUrl(imagePath.trim());
        } catch (Exception e) {
            log.warn("⚠️ Failed to resolve image URL: path={}, error={}", imagePath, e.getMessage());
            // fallback: trả lại path gốc
            return imagePath.trim();
        }
    }

    private List<String> resolveImageUrls(List<String> imagePaths) {
        if (CollectionUtils.isEmpty(imagePaths)) {
            return Collections.emptyList();
        }

        return imagePaths.stream()
                .filter(path -> path != null && !path.isBlank())
                .map(String::trim)
                .map(this::resolveImageUrl)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    // ========================================
    // 🔹 UTILITY METHODS
    // ========================================

    private String generateUUID() {
        return UUID.randomUUID().toString();
    }

    private String sanitizeString(String input) {
        if (input == null) return null;
        return input.trim();
    }

    private int countTotalSizeVariants(List<ColorVariantEntity> colors) {
        if (CollectionUtils.isEmpty(colors)) return 0;

        return colors.stream()
                .map(ColorVariantEntity::getSizes)
                .filter(sizes -> !CollectionUtils.isEmpty(sizes))
                .mapToInt(List::size)
                .sum();
    }
}
