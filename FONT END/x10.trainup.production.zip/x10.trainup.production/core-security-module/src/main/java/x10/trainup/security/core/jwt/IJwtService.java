package x10.trainup.security.core.jwt;

import x10.trainup.commons.domain.entities.UserEntity;

public interface IJwtService {
    String generateToken(String userId, String username, String email);
    String validateToken(String token);

    String generateAccessToken(UserEntity user);
    String generateRefreshToken(UserEntity user);


    String generateRecoveryToken(String email);
    String validateRecoveryToken(String token);


    String generateResetPasswordToken(String email);
    String validateResetPasswordTokenAndGetEmail(String token);

}
