package x10.trainup.security.core.principal;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface CustomUserDetailsService extends UserDetailsService {
    // chỉ giữ interface, không implement
}
