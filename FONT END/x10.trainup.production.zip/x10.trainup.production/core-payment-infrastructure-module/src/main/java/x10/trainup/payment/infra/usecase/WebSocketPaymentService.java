package x10.trainup.payment.infra.usecase;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class WebSocketPaymentService {

    private final SimpMessagingTemplate messagingTemplate;

    public void sendPaymentSuccess(Long orderCode) {
        log.info("📡 Gửi WebSocket PAYMENT_SUCCESS cho orderCode={}", orderCode);

        messagingTemplate.convertAndSend(
                "/topic/payment-status/" + orderCode,
                "PAID"
        );
    }
}
