package x10.trainup.payment.infra.usecase;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import vn.payos.PayOS;
import vn.payos.exception.PayOSException;
import vn.payos.model.v2.paymentRequests.CreatePaymentLinkRequest;
import vn.payos.model.v2.paymentRequests.CreatePaymentLinkResponse;
import x10.trainup.commons.domain.entities.PaymentEntity;
import x10.trainup.commons.domain.enums.PaymentMethod;
import x10.trainup.commons.domain.enums.PaymentOsStatus;
import x10.trainup.payment.core.usecase.ICorePaymentServiceUc;
import x10.trainup.payment.core.usecase.dto.CreatePaymentReq;
import x10.trainup.payment.core.usecase.dto.CreatePaymentRes;
import x10.trainup.payment.core.usecase.dto.PayOSWebhookDto;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class CorePaymentServiceUcImpl implements ICorePaymentServiceUc {

    private final PayOS payOS;
    private final WebSocketPaymentService webSocketPaymentService;

    @Override
    public CreatePaymentRes createBankTransferPayment(CreatePaymentReq req) {
        try {
            // ✅ validate số tiền
            if (req.getAmount() == null || req.getAmount() <= 0) {
                throw new IllegalArgumentException("Amount must be > 0");
            }

            long orderCode = System.currentTimeMillis() / 1000;

            // TODO: khi deploy thì đổi domain FE
            String baseUrl = "http://localhost:5173";

            CreatePaymentLinkRequest payOSReq = CreatePaymentLinkRequest.builder()
                    .orderCode(orderCode)
                    .amount(req.getAmount())
                    .description(req.getDescription())
                    .buyerName(req.getCustomerName())
                    .buyerEmail(req.getCustomerEmail())
                    .buyerPhone(req.getCustomerPhone())
                    .returnUrl(baseUrl + "/payment-success?orderCode=" + orderCode)
                    .cancelUrl(baseUrl + "/payment-cancel?orderCode=" + orderCode)
                    .build();

            log.info("[PayOS] Creating payment: orderCode={}, amount={}, returnUrl={}, cancelUrl={}",
                    orderCode, req.getAmount(),
                    payOSReq.getReturnUrl(), payOSReq.getCancelUrl());

            CreatePaymentLinkResponse payOSRes =
                    payOS.paymentRequests().create(payOSReq);

            log.info("[PayOS] Payment created: checkoutUrl={}, qrCode={}",
                    payOSRes.getCheckoutUrl(), payOSRes.getQrCode());

            PaymentEntity payment = PaymentEntity.builder()
                    .orderId(req.getOrderId())
                    .amount(req.getAmount())
                    .method(PaymentMethod.BANK)
                    .status(PaymentOsStatus.PENDING)
                    .provider("PAYOS")
                    .providerOrderCode(orderCode)
                    .createdAt(LocalDateTime.now())
                    .updatedAt(LocalDateTime.now())
                    .build();

            return CreatePaymentRes.builder()
                    .payment(payment)
                    .checkoutUrl(payOSRes.getCheckoutUrl())
                    .qrCode(payOSRes.getQrCode())
                    .build();

        } catch (PayOSException e) {
            throw new RuntimeException("Create payment with PayOS failed: " +  e);
        } catch (Exception e) {
            log.error("[PayOS] Unexpected error when creating payment", e);
            throw new RuntimeException("Create payment with PayOS failed", e);
        }
    }

    @Override
    public void handlePayOSWebhook(PayOSWebhookDto payload) {
        var data = payload.getData();

        // 1. Kiểm tra status từ PayOS
        if (!"00".equals(payload.getCode())) {
            log.warn("❌ Webhook PayOS có mã lỗi, bỏ qua: {}", payload);
            return;
        }

        Long orderCode = data.getOrderCode();

        log.info("🔔 [Webhook Handler] Bắt đầu xử lý orderCode={}", orderCode);

        // TODO: bạn cần gọi repository để tìm payment theo providerOrderCode
        // PaymentEntity payment = paymentRepository.findByProviderOrderCode(orderCode)
        //        .orElseThrow(() -> new RuntimeException("Payment not found"));

        // Ví dụ minh họa:


        // TODO: lưu vào database
        // paymentRepository.save(payment);

        log.info("✅ [Webhook Handler] Đã update payment thành công cho orderCode={}", orderCode);
        webSocketPaymentService.sendPaymentSuccess(orderCode);

        // TODO: nếu có WebSocket: gửi thông báo lên FE
        // websocketService.sendPaymentSuccess(orderCode);
    }
}
