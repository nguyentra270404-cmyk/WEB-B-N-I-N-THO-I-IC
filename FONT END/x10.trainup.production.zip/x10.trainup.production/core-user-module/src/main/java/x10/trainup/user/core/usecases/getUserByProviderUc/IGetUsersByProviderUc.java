package x10.trainup.user.core.usecases.getUserByProviderUc;

import x10.trainup.commons.domain.entities.UserEntity;

import java.util.List;

public interface IGetUsersByProviderUc {

    List<UserEntity> execute(String provider);
}
