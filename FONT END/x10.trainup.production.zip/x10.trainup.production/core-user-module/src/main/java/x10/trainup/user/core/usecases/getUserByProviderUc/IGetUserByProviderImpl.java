package x10.trainup.user.core.usecases.getUserByProviderUc;


import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import x10.trainup.commons.domain.entities.UserEntity;
import x10.trainup.commons.domain.enums.AuthProvider;
import x10.trainup.commons.exceptions.BusinessException;
import x10.trainup.user.core.errors.UserError;
import x10.trainup.user.core.repositories.IUserRepository;

import java.util.List;

@Service
@AllArgsConstructor
public class IGetUserByProviderImpl implements  IGetUsersByProviderUc{

    private final IUserRepository iUserRepository;

    @Override
    public List<UserEntity> execute(String provider) {
        try {
            // Convert String to AuthProvider enum
            AuthProvider authProvider = AuthProvider.valueOf(provider.toUpperCase());

            // Lấy users từ repository
            return iUserRepository.findByProvider(authProvider);

        } catch (IllegalArgumentException e) {
            // Nếu provider không hợp lệ
            throw new BusinessException(UserError.USER_NOT_FOUND);
        }
    }

}
