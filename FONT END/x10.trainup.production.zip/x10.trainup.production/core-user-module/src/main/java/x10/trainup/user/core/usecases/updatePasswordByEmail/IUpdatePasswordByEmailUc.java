package x10.trainup.user.core.usecases.updatePasswordByEmail;

public interface IUpdatePasswordByEmailUc {
    void process(UpdatePasswordByEmailReq req);
}
