package x10.trainup.product.infra.datascoures.mongodb;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SizeVariantDocument {

    private String id;               // ID size
    private String sizeName;         // 128GB, 256GB...

    private BigDecimal price;        // Giá gốc
    private BigDecimal discountPrice;// Giá giảm

    private int stock;               // Số lượng tồn kho
    private int sold;                // Đã bán bao nhiêu
}
