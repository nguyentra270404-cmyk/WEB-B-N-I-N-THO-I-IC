package x10.trainup.product.infra.adapters.mapper;

import x10.trainup.commons.domain.entities.SizeVariantEntity;
import x10.trainup.product.infra.datascoures.mongodb.SizeVariantDocument;

public class SizeVariantMapper {

    public static SizeVariantDocument toDocument(SizeVariantEntity entity) {
        if (entity == null) return null;

        return SizeVariantDocument.builder()
                .id(entity.getId())
                .sizeName(entity.getSizeName())
                .price(entity.getPrice())
                .discountPrice(entity.getDiscountPrice())
                .stock(entity.getStock())
                .sold(entity.getSold())
                .build();
    }

    public static SizeVariantEntity toEntity(SizeVariantDocument doc) {
        if (doc == null) return null;

        return SizeVariantEntity.builder()
                .id(doc.getId())
                .sizeName(doc.getSizeName())
                .price(doc.getPrice())
                .discountPrice(doc.getDiscountPrice())
                .stock(doc.getStock())
                .sold(doc.getSold())
                .build();
    }
}
