package x10.trainup.product.infra.adapters.mapper;

import x10.trainup.commons.domain.entities.ColorVariantEntity;
import x10.trainup.product.infra.datascoures.mongodb.ColorVariantDocument;

import java.util.stream.Collectors;

public class ColorVariantMapper {

    public static ColorVariantDocument toDocument(ColorVariantEntity entity) {
        if (entity == null) return null;

        return ColorVariantDocument.builder()
                .id(entity.getId())
                .colorName(entity.getColorName())
                .colorCode(entity.getColorCode())
                .mainImage(entity.getMainImage())
                .imageUrls(entity.getImageUrls())
                .sizes(entity.getSizes() != null
                        ? entity.getSizes().stream()
                        .map(SizeVariantMapper::toDocument)
                        .collect(Collectors.toList())
                        : null)
                .build();
    }

    public static ColorVariantEntity toEntity(ColorVariantDocument doc) {
        if (doc == null) return null;

        return ColorVariantEntity.builder()
                .id(doc.getId())
                .colorName(doc.getColorName())
                .colorCode(doc.getColorCode())
                .mainImage(doc.getMainImage())
                .imageUrls(doc.getImageUrls())
                .sizes(doc.getSizes() != null
                        ? doc.getSizes().stream()
                        .map(SizeVariantMapper::toEntity)
                        .collect(Collectors.toList())
                        : null)
                .build();
    }
}
