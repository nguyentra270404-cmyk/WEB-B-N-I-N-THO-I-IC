package x10.trainup.product.infra.datascoures.mongodb;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ColorVariantDocument {

    private String id;          // ID màu
    private String colorName;   // Ví dụ: Đen, Xanh dương
    private String colorCode;   // Mã hex
    private String mainImage;   // Ảnh chính của màu
    private List<String> imageUrls; // Ảnh phụ (0–4 ảnh)

    private List<SizeVariantDocument> sizes; // Danh sách size (128GB, 256GB...)
}
