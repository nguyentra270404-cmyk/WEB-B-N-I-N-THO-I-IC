    package x10.trainup.api.portal.controllers.orderController;
    import jakarta.servlet.http.HttpServletRequest;
    import jakarta.validation.Valid;
    import lombok.AllArgsConstructor;
    import org.slf4j.MDC;
    import org.springframework.http.HttpStatus;
    import org.springframework.http.ResponseEntity;
    import org.springframework.web.bind.annotation.*;
    import x10.trainup.commons.domain.entities.OrderEntity;
    import x10.trainup.commons.response.ApiResponse;
    import x10.trainup.order.core.usecases.ICoreOrderService;
    import x10.trainup.order.core.usecases.cancelOrder.CancelOrderReq;
    import x10.trainup.order.core.usecases.createOrder.CreateOrderReq;

    import java.util.List;

    @RestController
    @RequestMapping("api/orders")
    @AllArgsConstructor
    public class OrderController {

        private final ICoreOrderService orderService;
        private final HttpServletRequest request;

        private String path() {
            return request.getRequestURI();
        }

        private String traceId() {
            var id = (String) request.getAttribute("traceId");
            return (id != null) ? id : MDC.get("traceId");
        }

        @PostMapping("/create")
        public ResponseEntity<ApiResponse<OrderEntity>> createOrder(
                @RequestBody @Valid CreateOrderReq req
        ) {
            OrderEntity order = orderService.createOrder(req);
            ApiResponse<OrderEntity> response = ApiResponse.of(
                    201,
                    "ORDER.CREATED",
                    "Đơn hàng đã được tạo thành công",
                    order,
                    path(),
                    traceId()
            );
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        }
        @GetMapping("/user/{userId}")
        public ResponseEntity<ApiResponse<List<OrderEntity>>> getOrdersByUserId(
                @PathVariable String userId
        ) {
            List<OrderEntity> orders = orderService.getOrdersByUserId(userId);
            ApiResponse<List<OrderEntity>> response = ApiResponse.of(
                    200,
                    "ORDER.LIST_BY_USER_SUCCESS",
                    "Lấy danh sách đơn hàng của người dùng thành công",
                    orders,
                    path(),
                    traceId()
            );

            return ResponseEntity.ok(response);
        }

        @PutMapping("/cancel")
        public ResponseEntity<ApiResponse<Void>> cancelOrder(
                @RequestBody @Valid CancelOrderReq req
        ) {
            orderService.cancelOrder(req);

            ApiResponse<Void> response = ApiResponse.of(
                    200,
                    "ORDER.CANCELED",
                    "Huỷ đơn hàng thành công",
                    null,
                    path(),
                    traceId()
            );

            return ResponseEntity.ok(response);
        }
    }