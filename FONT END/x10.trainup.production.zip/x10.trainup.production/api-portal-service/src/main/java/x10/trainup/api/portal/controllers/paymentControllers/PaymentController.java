package x10.trainup.api.portal.controllers.paymentControllers;




import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import x10.trainup.commons.response.ApiResponse;
import x10.trainup.payment.core.usecase.ICorePaymentServiceUc;
import x10.trainup.payment.core.usecase.dto.CreatePaymentReq;
import x10.trainup.payment.core.usecase.dto.CreatePaymentRes;
import x10.trainup.payment.core.usecase.dto.PayOSWebhookDto;

@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
@Slf4j
public class PaymentController {

    private final ICorePaymentServiceUc paymentService;
    private final HttpServletRequest request;
    private String path() {
        return request.getRequestURI();
    }

    private String traceId() {
        var id = (String) request.getAttribute("traceId");
        if (id == null) id = MDC.get("traceId");
        return id;
    }
    @PostMapping("/create-bank-transfer")
    public ResponseEntity<ApiResponse<CreatePaymentRes>> createBankTransfer(
            @Valid @RequestBody CreatePaymentReq req,
            HttpServletRequest httpRequest
    ) {
        CreatePaymentRes result = paymentService.createBankTransferPayment(req);

        ApiResponse<CreatePaymentRes> response = ApiResponse.of(
                200,
                "PAYMENT.LINK.CREATED",
                "Tạo link thanh toán thành công",
                result,
                path(),
                traceId()
        );

        return ResponseEntity.ok(response);
    }
    @PostMapping("/webhook/payos")
    public ResponseEntity<String> handlePayOSWebhook(@RequestBody PayOSWebhookDto payload) {
        log.info("🔔 [PayOS Webhook] orderCode={}, amount={}, reference={}",
                payload.getData().getOrderCode(),
                payload.getData().getAmount(),
                payload.getData().getReference()
        );

        paymentService.handlePayOSWebhook(payload);

        return ResponseEntity.ok("OK");
    }

}
