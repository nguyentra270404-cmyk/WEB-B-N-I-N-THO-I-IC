package x10.trainup.commons.domain.entities;


import lombok.Builder;
import lombok.Data;
import x10.trainup.commons.domain.enums.PaymentMethod;
import x10.trainup.commons.domain.enums.PaymentOsStatus;

import java.time.LocalDateTime;

@Data
@Builder
public class PaymentEntity {

    private Long id;
    private Long orderId;

    private Long amount;
    private PaymentMethod method;     // COD / BANK_TRANSFER (enum bạn vừa tạo)
    private PaymentOsStatus status;     // PENDING / PAID...

    private Long providerOrderCode;   // orderCode bên PayOS
    private String provider;          // "PAYOS"
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}