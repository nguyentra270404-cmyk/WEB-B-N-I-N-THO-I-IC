package x10.trainup.commons.domain.enums;

public enum PaymentStatus {
    UNPAID,             // Chưa thanh toán
    PAID                // Đã thanh toán
}