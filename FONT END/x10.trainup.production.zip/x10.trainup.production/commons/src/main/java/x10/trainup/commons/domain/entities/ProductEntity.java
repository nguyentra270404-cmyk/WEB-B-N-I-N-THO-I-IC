package x10.trainup.commons.domain.entities;

import lombok.*;
import java.time.Instant;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProductEntity {
    private String id;                        // ID sản phẩm
    private String name;                      // Tên sản phẩm
    private String description;               // Mô tả chung
    private String categoryId;                // Loại / danh mục
    private String brand;                     // Thương hiệu
    private Instant createdAt;                // Ngày tạo
    private Instant updatedAt;                // Ngày cập nhật
    private boolean active;                   // Trạng thái hoạt động
    private List<ColorVariantEntity> colors;  // Danh sách màu sắc + ảnh + kích thước
}
