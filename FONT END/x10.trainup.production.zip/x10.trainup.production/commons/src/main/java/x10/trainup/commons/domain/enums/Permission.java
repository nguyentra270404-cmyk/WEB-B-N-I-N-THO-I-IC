package x10.trainup.commons.domain.enums;


public enum Permission {
    CREATE_POST,      // Tạo bài đăng
    DELETE_POST,      // Xóa bài đăng
    VIEW_SCHEDULE,    // Xem lịch tập
    BOOK_SESSION,     // Đặt buổi tập
    CREATE_SESSION    // Tạo buổi tập
}
