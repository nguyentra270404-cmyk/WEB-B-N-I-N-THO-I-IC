package x10.trainup.commons.domain.entities;

import lombok.*;
import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SizeVariantEntity {
    private String id;                   // ID của từng kích thước
    private String sizeName;             // 128GB, 256GB, 512GB...
    private BigDecimal price;            // Giá thường
    private BigDecimal discountPrice;    // Giá giảm
    private int stock;                   // Tồn kho còn lại
    private int sold;                    // Đã bán bao nhiêu
}
