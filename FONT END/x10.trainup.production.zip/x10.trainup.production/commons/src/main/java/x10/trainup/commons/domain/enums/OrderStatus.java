package x10.trainup.commons.domain.enums;

public enum OrderStatus {
    PENDING,            // Chờ xác nhận
    CONFIRMED,          // Đã xác nhận
    CANCELLED           // Đã hủy
}

