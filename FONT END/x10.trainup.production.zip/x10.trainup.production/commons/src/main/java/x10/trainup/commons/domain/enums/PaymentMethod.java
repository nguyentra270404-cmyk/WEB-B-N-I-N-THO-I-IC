package x10.trainup.commons.domain.enums;

public enum PaymentMethod {
    COD,            
    BANK,
}
