package x10.trainup.commons.domain.enums;

public enum PaymentOsStatus {
    PENDING,
    PAID,
    FAILED,
    CANCELED
}
