package x10.trainup.commons.ports;

public interface IProductQueryService {

    boolean existsByCategoryId(String categoryId);
}
