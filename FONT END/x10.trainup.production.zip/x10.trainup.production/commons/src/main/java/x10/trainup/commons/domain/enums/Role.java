package x10.trainup.commons.domain.enums;

public enum Role {
    CUSTOMER,
    TRAINER,
    ADMIN,
    GUEST
}
