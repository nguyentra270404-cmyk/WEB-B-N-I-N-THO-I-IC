package x10.trainup.commons.domain.enums;

public enum AuthProvider {
    LOCAL,    // Đăng ký bằng email & password
    GOOGLE,   // Đăng nhập bằng Google
    GUEST  // ← Thêm provider cho guest use
}
