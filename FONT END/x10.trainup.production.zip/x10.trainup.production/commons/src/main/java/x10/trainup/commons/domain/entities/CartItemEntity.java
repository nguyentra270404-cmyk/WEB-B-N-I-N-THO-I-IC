package x10.trainup.commons.domain.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CartItemEntity {

    private String productId;
    private String productName;

    private String colorId;
    private String colorName;

    private String sizeId;
    private String sizeName;

    private BigDecimal price;
    private int quantity;

    private String imageUrl;
}
