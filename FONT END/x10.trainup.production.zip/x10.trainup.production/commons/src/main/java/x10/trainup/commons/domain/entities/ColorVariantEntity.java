package x10.trainup.commons.domain.entities;

import lombok.*;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ColorVariantEntity {
    private String id;                 // ID màu
    private String colorName;          // Tên màu, ví dụ "Xanh đậm", "Cam"
    private String colorCode;          // Mã màu hex, ví dụ "#FF6600", "#0033FF"
    private String mainImage;          // Ảnh chính màu
    private List<String> imageUrls;    // Ảnh phụ màu
    private List<SizeVariantEntity> sizes; // Các kích thước/dung lượng
}
