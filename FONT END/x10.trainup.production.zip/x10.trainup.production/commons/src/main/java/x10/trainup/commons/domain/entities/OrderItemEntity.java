package x10.trainup.commons.domain.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrderItemEntity {

    private String productId;       // ID sản phẩm
    private String productName;     // Tên sản phẩm (snapshot)

    private String colorId;         // ID màu
    private String colorName;       // Tên màu (snapshot)
    private String mainImage;       // Ảnh chính theo màu

    private String sizeId;          // ID size
    private String sizeName;        // Tên size (128GB, 256GB,...)

    private BigDecimal price;       // Giá tại thời điểm đặt
    private int quantity;           // Số lượng đặt
    private BigDecimal subtotal;    // price * quantity
}
