package x10.trainup.media.core.usecases.presignUpload;

public interface IPresignUpload {

    PresignUploadRes presignUpload(PresignUploadReq req);
}
