package x10.trainup.media.core.usecases.uploadMedia;

public interface IUploadMediaUc {
    UploadMediaRes uploadMedia(UploadMediaReq req);
}