package x10.trainup.media.core.usecases.deleteMedia;

public interface IDeleteMediaUc {
    boolean deleteMedia(DeleteMediaReq req);
}
