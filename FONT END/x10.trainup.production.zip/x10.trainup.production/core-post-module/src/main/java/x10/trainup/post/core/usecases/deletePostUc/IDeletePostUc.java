package x10.trainup.post.core.usecases.deletePostUc;
public interface IDeletePostUc {
    void delete(String postId, String authorId);
}
