package x10.trainup.shop.core.usecases;

import x10.trainup.commons.domain.entities.ShopEntity;
import x10.trainup.shop.core.usecases.createShop.CreateShopReq;
import x10.trainup.shop.core.usecases.updateAddress.UpdateShopAddressReq;

import java.util.List;
import java.util.Optional;

public interface ICoreShopServiceUc {

    ShopEntity create(CreateShopReq req);

    List<ShopEntity> getAll();

    Optional<ShopEntity>getByTen(String tenShop);

    ShopEntity updateAddress(UpdateShopAddressReq req);
}

