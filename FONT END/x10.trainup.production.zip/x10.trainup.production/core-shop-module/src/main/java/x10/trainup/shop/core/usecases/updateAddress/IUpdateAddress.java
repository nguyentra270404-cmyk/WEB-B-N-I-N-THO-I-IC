package x10.trainup.shop.core.usecases.updateAddress;

import x10.trainup.commons.domain.entities.ShopEntity;

public interface IUpdateAddress {

    ShopEntity updateAddress(UpdateShopAddressReq req);

}
