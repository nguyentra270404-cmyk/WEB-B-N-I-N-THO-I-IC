package x10.trainup.shop.core.usecases.updateAddress;

import lombok.Data;

@Data
public class UpdateShopAddressReq {
    private String shopId;

    private String street;
    private String ward;
    private String district;
    private String province;
    private String country;

    private Integer provinceId;
    private Integer districtId;
    private Integer wardCode;
}
