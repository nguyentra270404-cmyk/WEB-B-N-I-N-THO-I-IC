package x10.trainup.shop.core.usecases.updateAddress;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import x10.trainup.commons.domain.entities.AddressEntity;
import x10.trainup.commons.domain.entities.ShopEntity;
import x10.trainup.commons.exceptions.BusinessException;
import x10.trainup.shop.core.errors.ShopErrors;
import x10.trainup.shop.core.repository.IRepositoryShop;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
@AllArgsConstructor
public class UpdateAddressImpl implements IUpdateAddress {

    private final IRepositoryShop repositoryShop;

    @Override
    public ShopEntity updateAddress(UpdateShopAddressReq req) {

        // 🔍 Validate shopId
        if (req.getShopId() == null || req.getShopId().trim().isEmpty()) {
            throw new BusinessException(
                    ShopErrors.INVALID_SHOP_DATA,
                    "Shop ID is required"
            );
        }

        // 🔍 Tìm shop theo ID
        ShopEntity shop = repositoryShop.findById(req.getShopId())
                .orElseThrow(() -> new BusinessException(
                        ShopErrors.SHOP_NOT_FOUND,
                        "Shop with ID " + req.getShopId() + " not found"
                ));

        // 🔍 Validate address (tất cả đều null => không update gì)
        if (req.getStreet() == null &&
                req.getWard() == null &&
                req.getDistrict() == null &&
                req.getProvince() == null &&
                req.getCountry() == null &&
                req.getProvinceId() == null &&
                req.getDistrictId() == null &&
                req.getWardCode() == null) {

            throw new BusinessException(
                    ShopErrors.INVALID_ADDRESS_DATA,
                    "At least 1 address field must be provided"
            );
        }

        try {
            AddressEntity currentAddr = shop.getAddressEntity();
            if (currentAddr == null) {
                currentAddr = new AddressEntity();
            }

            // 🔧 Update từng field (null thì bỏ qua)
            if (req.getStreet() != null) currentAddr.setStreet(req.getStreet());
            if (req.getWard() != null) currentAddr.setWard(req.getWard());
            if (req.getDistrict() != null) currentAddr.setDistrict(req.getDistrict());
            if (req.getProvince() != null) currentAddr.setProvince(req.getProvince());
            if (req.getCountry() != null) currentAddr.setCountry(req.getCountry());

            if (req.getProvinceId() != null) currentAddr.setProvinceId(req.getProvinceId());
            if (req.getDistrictId() != null) currentAddr.setDistrictId(req.getDistrictId());
            if (req.getWardCode() != null) currentAddr.setWardCode(req.getWardCode());

            shop.setAddressEntity(currentAddr);

            // 💾 Save to db
            ShopEntity saved = repositoryShop.save(shop);

            log.info("Address of shop {} updated successfully", saved.getId());

            return saved;

        } catch (NumberFormatException e) {

            Map<String, Object> details = new HashMap<>();
            details.put("wardCode", req.getWardCode());

            throw new BusinessException(
                    ShopErrors.INVALID_ADDRESS_DATA,
                    "wardCode must be numeric",
                    details
            );

        } catch (Exception e) {

            log.error("Failed to update shop address: {}", e.getMessage(), e);

            throw new BusinessException(
                    ShopErrors.SHOP_CREATION_FAILED,
                    "Failed to update address: " + e.getMessage()
            );
        }
    }
}
