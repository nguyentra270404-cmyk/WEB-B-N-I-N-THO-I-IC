package x10.trainup.shop.core.usecases;


import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import x10.trainup.commons.domain.entities.ShopEntity;
import x10.trainup.shop.core.repository.IRepositoryShop;
import x10.trainup.shop.core.usecases.createShop.CreateShopReq;
import x10.trainup.shop.core.usecases.createShop.ICreateShopServiceUc;
import x10.trainup.shop.core.usecases.updateAddress.IUpdateAddress;
import x10.trainup.shop.core.usecases.updateAddress.UpdateShopAddressReq;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class CoreShopServiceImpl implements  ICoreShopServiceUc {

    private final ICreateShopServiceUc iCreateShopServiceUc;
    private final IRepositoryShop iRepositoryShop;
    private final IUpdateAddress iUpdateAddress;

    @Override
    public ShopEntity updateAddress(UpdateShopAddressReq req){
        return  iUpdateAddress.updateAddress(req);
    }

    @Override
    public ShopEntity create(CreateShopReq req){
            return iCreateShopServiceUc.process(req);
    }

    @Override
    public List<ShopEntity> getAll(){
        return iRepositoryShop.findAll();
    }

    @Override
    public Optional<ShopEntity> getByTen(String tenShop){
        return iRepositoryShop.findByName(tenShop);
    }

}
