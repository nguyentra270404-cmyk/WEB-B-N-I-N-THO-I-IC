package x10.trainup.cart.infra.datasources.mongo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CartItemDocument {

    private String productId;      // ID sản phẩm
    private String productName;    // Tên sản phẩm

    private String colorId;        // ID màu
    private String colorName;      // Tên màu (ví dụ: Đen, Trắng, Xanh)

    private String sizeId;         // ID dung lượng (128GB, 256GB)
    private String sizeName;       // Tên dung lượng

    private BigDecimal price;      // Giá tại thời điểm thêm vào giỏ
    private int quantity;          // Số lượng
    private String imageUrl;       // Ảnh sản phẩm theo màu
}
