package x10.trainup.category.core.usecases.deleteCategoryUc;

public interface IDeleteCategoryUc {

    void process(String categoryId);
}
