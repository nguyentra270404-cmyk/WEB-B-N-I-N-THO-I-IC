package x10.trainup.auth.core.usecases.resendVerificationEmailUc;

public interface IResendVerificationEmailUc {
    void  proccess(String email);
}
