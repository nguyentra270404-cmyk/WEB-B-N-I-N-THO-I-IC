package x10.trainup.auth.core.usecases.signUpUc;

public interface ISignUpUc {

    SignUpResp proccess(SignUpReq req);
}
