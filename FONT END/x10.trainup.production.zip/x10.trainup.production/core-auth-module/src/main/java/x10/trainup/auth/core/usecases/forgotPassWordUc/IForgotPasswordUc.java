package x10.trainup.auth.core.usecases.forgotPassWordUc;

public interface IForgotPasswordUc {
    ForgotPasswordRes execute(ForgotPasswordReq req);
}
