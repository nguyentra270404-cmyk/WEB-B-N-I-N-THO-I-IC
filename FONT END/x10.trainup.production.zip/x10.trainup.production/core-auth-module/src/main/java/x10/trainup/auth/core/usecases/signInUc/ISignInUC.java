package x10.trainup.auth.core.usecases.signInUc;




public interface ISignInUC {
    SignInResp process(SignInReq req);

}
