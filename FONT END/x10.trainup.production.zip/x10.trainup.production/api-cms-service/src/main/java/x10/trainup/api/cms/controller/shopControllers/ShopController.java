package x10.trainup.api.cms.controller.shopControllers;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import x10.trainup.commons.domain.entities.ShopEntity;
import x10.trainup.commons.response.ApiResponse;
import x10.trainup.shop.core.usecases.ICoreShopServiceUc;
import x10.trainup.shop.core.usecases.createShop.CreateShopReq;
import x10.trainup.shop.core.usecases.updateAddress.UpdateShopAddressReq;

import java.util.List;

@RestController
@RequestMapping("/api/shops")
@AllArgsConstructor
public class ShopController {



    private final ICoreShopServiceUc shopService;
    private final HttpServletRequest request;

    private String path() {
        return request.getRequestURI();
    }

    private String traceId() {
        var id = (String) request.getAttribute("traceId");
        if (id == null) id = MDC.get("traceId");
        return id;
    }
    @PostMapping
    public ResponseEntity<ApiResponse<ShopEntity>> create(
            @Valid @RequestBody CreateShopReq req,
            HttpServletRequest request
    ) {
        ShopEntity createdShop = shopService.create(req);

        ApiResponse<ShopEntity> response = ApiResponse.of(
                HttpStatus.CREATED.value(),
                "SHOP.CREATED",
                "Shop created successfully",
                createdShop,
                path(),
                traceId()


        );

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(response);
    }


    @GetMapping
    public ResponseEntity<ApiResponse<List<ShopEntity>>> getAll(
            HttpServletRequest request
    ) {
        List<ShopEntity> shops = shopService.getAll();

        ApiResponse<List<ShopEntity>> response = ApiResponse.of(
                HttpStatus.OK.value(),
                "SHOP.LIST",
                "Get all shops successfully",
                shops,
                path(),
                traceId()
        );

        return ResponseEntity.ok(response);
    }

    @PutMapping("/address")
    public ResponseEntity<ApiResponse<ShopEntity>> updateAddress(
            @Valid @RequestBody UpdateShopAddressReq req,
            HttpServletRequest request
    ) {
        ShopEntity updated = shopService.updateAddress(req);

        ApiResponse<ShopEntity> response = ApiResponse.of(
                HttpStatus.OK.value(),
                "SHOP.ADDRESS_UPDATED",
                "Shop address updated successfully",
                updated, path(),
                traceId()

        );

        return ResponseEntity.ok(response);
    }


}
