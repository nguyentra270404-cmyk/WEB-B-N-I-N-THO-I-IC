package x10.trainup.api.cms.controller.userController;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import x10.trainup.commons.domain.entities.UserEntity;
import x10.trainup.commons.response.ApiResponse;
import x10.trainup.user.core.usecases.ICoreUserSerivce;
import x10.trainup.user.core.usecases.updateStatusUserUc.UpdateUserStatusReq;

import java.util.List;

@RestController
@RequestMapping("/api/users")
@AllArgsConstructor
public class UserController {
    private final ICoreUserSerivce iCoreUserSerivce;
    private final HttpServletRequest request;

    private String path() {
        return request.getRequestURI();
    }

    private String traceId() {
        var id = (String) request.getAttribute("traceId");
        if (id == null) id = MDC.get("traceId");
        if (id == null) id = request.getHeader("X-Trace-Id");
        return id;
    }

    /**
     * Lấy tất cả users
     * GET /api/users/all
     */
    @GetMapping("/all")
    public ResponseEntity<ApiResponse<List<UserEntity>>> getAllUsers() {
        List<UserEntity> users = iCoreUserSerivce.getAllUsers();

        ApiResponse<List<UserEntity>> response = ApiResponse.of(
                HttpStatus.OK.value(),
                "USER.GET_ALL_SUCCESS",
                "Retrieved all users successfully",
                users,
                path(),
                traceId()
        );

        return ResponseEntity.ok(response);
    }

    /**
     * Cập nhật trạng thái user
     * PATCH /api/users/{userId}/status
     */
    @PatchMapping("/{userId}/status")
    public ResponseEntity<ApiResponse<UserEntity>> updateUserStatus(
            @PathVariable String userId,
            @Valid @RequestBody UpdateUserStatusReq req) {

        UserEntity user = iCoreUserSerivce.updateUserStatus(userId, req);

        ApiResponse<UserEntity> response = ApiResponse.of(
                HttpStatus.OK.value(),
                "USER.STATUS_UPDATE_SUCCESS",
                "User status updated successfully",
                user,
                path(),
                traceId()
        );

        return ResponseEntity.ok(response);
    }


    @GetMapping("/by-provider/{provider}")
    public ResponseEntity<ApiResponse<List<UserEntity>>> getUsersByProvider(
            @PathVariable String provider) {

        List<UserEntity> users = iCoreUserSerivce.getUsersByProvider(provider);

        ApiResponse<List<UserEntity>> response = ApiResponse.of(
                HttpStatus.OK.value(),
                "USER.GET_BY_PROVIDER_SUCCESS",
                "Users retrieved by provider successfully",
                users,
                path(),
                traceId()
        );

        return ResponseEntity.ok(response);
    }
}