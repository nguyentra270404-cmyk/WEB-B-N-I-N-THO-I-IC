package x10.trainup.api.cms.controller.orderController;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import x10.trainup.commons.domain.entities.OrderEntity;
import x10.trainup.commons.response.ApiResponse;
import x10.trainup.order.core.usecases.ICoreOrderService;
import x10.trainup.order.core.usecases.createOrder.CreateOrderReq;
import x10.trainup.order.core.usecases.updateOrderStatusUc.UpdateOrderStatusReq;

import java.util.List;

@RestController
@RequestMapping("api/orders")
@AllArgsConstructor
public class OrderController {

    private final ICoreOrderService orderService;
    private final HttpServletRequest request;
    private String path() {
        return request.getRequestURI();
    }
    private String traceId() {
        var id = (String) request.getAttribute("traceId");
        if (id == null) id = "trace-" + System.currentTimeMillis();
        return id;
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<OrderEntity>>> getAllOrders() {
        List<OrderEntity> orders = orderService.getAllOrdersSortedByDateDesc();
        ApiResponse<List<OrderEntity>> response = ApiResponse.of(
                200,
                "ORDER.LIST_SUCCESS",
                "Lấy danh sách đơn hàng thành công",
                orders,
                path(),
                traceId()
        );
        return ResponseEntity.ok(response);
    }

    @PatchMapping("/status")
    public ResponseEntity<ApiResponse<Void>> updateOrderStatus(
            @Valid @RequestBody UpdateOrderStatusReq req
    ) {
        orderService.updateOrderStatus(req);

        ApiResponse<Void> response = ApiResponse.of(
                200,
                "ORDER.UPDATE_STATUS_SUCCESS",
                "Cập nhật trạng thái đơn hàng thành công",
                null,
                path(),
                traceId()
        );

        return ResponseEntity.ok(response);
    }
}