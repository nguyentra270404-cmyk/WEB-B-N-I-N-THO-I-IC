package x10.trainup.mailbox.core.usecases.sendForgotPasswordOtpUc;

public interface ISendForgotPasswordOtpUc {
    void execute(SendForgotPasswordOtpReq req);
}
