package x10.trainup.mailbox.core.usecases.sendVerificationEmailUc;

public interface SendVerificationEmailUc {

    void proccess(sendVerificationEmailReq req);
}
