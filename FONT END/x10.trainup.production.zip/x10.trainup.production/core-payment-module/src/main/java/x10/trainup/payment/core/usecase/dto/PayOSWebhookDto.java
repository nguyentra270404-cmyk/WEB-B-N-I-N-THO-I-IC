package x10.trainup.payment.core.usecase.dto;

import lombok.Data;

@Data
public class PayOSWebhookDto {
    private String code;   // "00"
    private String desc;   // "success"
    private WebhookData data;

    @Data
    public static class WebhookData {
        private Long orderCode;            // 123
        private Long amount;               // 3000
        private String description;        // "VQR1023"
        private String accountNumber;      // "12345678"
        private String reference;          // "TF2523..."
        private String transactionDateTime;// "2025-11-21 17:18:03"
        private String paymentLinkId;      // "..."
        private String code;               // "00"
        private String desc;               // "Thành công"
        private String counterAccountBankId;
        private String counterAccountNumber;
        private String virtualAccountName;
        private String virtualAccountNumber;
        private String currency;           // "VND"
        private String signature;          // "1965e0..."
    }
}
