// x10.trainup.payment.core.usecase.dto.CreatePaymentRes
package x10.trainup.payment.core.usecase.dto;

import lombok.Builder;
import lombok.Data;
import x10.trainup.commons.domain.entities.PaymentEntity;

@Data
@Builder
public class CreatePaymentRes {

    private PaymentEntity payment; // thông tin payment trong hệ thống
    private String checkoutUrl;    // link thanh toán PayOS
    private String qrCode;         // base64 / url ảnh QR (PayOS trả về)
}
