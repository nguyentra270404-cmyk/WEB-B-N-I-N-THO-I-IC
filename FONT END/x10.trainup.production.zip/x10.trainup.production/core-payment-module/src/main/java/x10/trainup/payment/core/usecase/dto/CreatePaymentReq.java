// x10.trainup.payment.core.usecase.dto.CreatePaymentReq
package x10.trainup.payment.core.usecase.dto;

import lombok.Data;

@Data
public class CreatePaymentReq {

    private Long orderId;        // id đơn hàng nội bộ (nếu đã có)
    private Long amount;         // số tiền (VND)
    private String description;  // mô tả hiển thị trên PayOS
    private String customerName;
    private String customerEmail;
    private String customerPhone;
}
