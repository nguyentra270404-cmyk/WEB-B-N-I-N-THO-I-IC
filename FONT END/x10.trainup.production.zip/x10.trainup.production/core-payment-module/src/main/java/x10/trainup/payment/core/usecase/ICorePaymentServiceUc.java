package x10.trainup.payment.core.usecase;

import x10.trainup.payment.core.usecase.dto.CreatePaymentReq;
import x10.trainup.payment.core.usecase.dto.CreatePaymentRes;
import x10.trainup.payment.core.usecase.dto.PayOSWebhookDto;

public interface ICorePaymentServiceUc {

    CreatePaymentRes createBankTransferPayment(CreatePaymentReq req);

    void handlePayOSWebhook(PayOSWebhookDto payload);
}

