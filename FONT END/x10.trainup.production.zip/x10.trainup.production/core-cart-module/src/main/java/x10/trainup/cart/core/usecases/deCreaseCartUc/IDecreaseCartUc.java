package x10.trainup.cart.core.usecases.deCreaseCartUc;

public interface IDecreaseCartUc {

    void excute(DecreaseReq req,String userId);
}
