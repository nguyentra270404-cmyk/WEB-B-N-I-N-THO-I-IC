package x10.trainup.cart.core.usecases.RemoveListItemsUC;

public interface IRemoveListItemsUc {
    void execute(RemoveListItemsReq req, String userId);
}