package x10.trainup.cart.core.usecases.cleanCartUc;

public interface IClearCartUc {
    void execute(String UserId);
}