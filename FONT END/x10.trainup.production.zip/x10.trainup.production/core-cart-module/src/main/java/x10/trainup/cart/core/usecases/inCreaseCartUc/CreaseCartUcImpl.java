package x10.trainup.cart.core.usecases.inCreaseCartUc;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import x10.trainup.cart.core.error.CartError;
import x10.trainup.cart.core.repository.IRepositoryCart;
import x10.trainup.commons.domain.entities.CartEntity;
import x10.trainup.commons.domain.entities.CartItemEntity;
import x10.trainup.commons.domain.entities.ColorVariantEntity;
import x10.trainup.commons.domain.entities.ProductEntity;
import x10.trainup.commons.domain.entities.SizeVariantEntity;
import x10.trainup.commons.exceptions.BusinessException;
import x10.trainup.product.core.repositories.IRepositoryProduct;
import x10.trainup.user.core.errors.UserError;
import x10.trainup.user.core.usecases.ICoreUserSerivce;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class CreaseCartUcImpl implements IInCreaseCartUC {

    private final ICoreUserSerivce iCoreUserSerivce;
    private final IRepositoryCart iRepositoryCart;
    private final IRepositoryProduct iRepositoryProduct;

    @Override
    public void increase(IncreaseCartReq req, String userId) {

        // 1️⃣ Kiểm tra user tồn tại
        if (!iCoreUserSerivce.existsById(userId)) {
            throw new BusinessException(UserError.USER_NOT_FOUND, "Không tìm thấy người dùng.");
        }

        // 2️⃣ Tìm giỏ hàng hiện có
        CartEntity cart = iRepositoryCart.findByUserId(userId)
                .orElseThrow(() -> new BusinessException(
                        CartError.CART_NOT_FOUND,
                        "Không tìm thấy giỏ hàng của người dùng.")
                );

        // 3️⃣ Kiểm tra sản phẩm có tồn tại
        ProductEntity product = iRepositoryProduct.findById(req.getProductId())
                .orElseThrow(() -> new BusinessException(
                        CartError.PRODUCT_NOT_FOUND,
                        "ProductId: " + req.getProductId() + " không tồn tại.")
                );

        // 4️⃣ Tìm color trong product
        ColorVariantEntity color = Optional.ofNullable(product.getColors())
                .orElse(List.of())
                .stream()
                .filter(c -> c.getId() != null && c.getId().equals(req.getColorId()))
                .findFirst()
                .orElseThrow(() -> new BusinessException(
                        CartError.COLOR_NOT_FOUND,
                        "ColorId: " + req.getColorId() + " không tồn tại trong product: " + req.getProductId())
                );

        // 5️⃣ Tìm size trong color
        SizeVariantEntity size = Optional.ofNullable(color.getSizes())
                .orElse(List.of())
                .stream()
                .filter(s -> s.getId() != null && s.getId().equals(req.getSizeId()))
                .findFirst()
                .orElseThrow(() -> new BusinessException(
                        CartError.SIZE_NOT_FOUND,
                        "SizeId: " + req.getSizeId() + " không tồn tại trong color: " + req.getColorId())
                );

        // 6️⃣ Tìm item tương ứng trong cart (product + color + size)
        CartItemEntity targetItem = null;
        for (CartItemEntity item : cart.getItems()) {
            boolean sameProduct = item.getProductId().equals(req.getProductId());
            boolean sameColor   = item.getColorId().equals(req.getColorId());
            boolean sameSize    = item.getSizeId().equals(req.getSizeId());

            if (sameProduct && sameColor && sameSize) {
                targetItem = item;
                break;
            }
        }

        // Nếu không thấy item → lỗi
        if (targetItem == null) {
            throw new BusinessException(
                    CartError.ITEM_NOT_FOUND,
                    "Không tìm thấy sản phẩm trong giỏ hàng."
            );
        }

        // 7️⃣ Kiểm tra tồn kho trước khi tăng
        int currentQuantity = targetItem.getQuantity();
        int newQuantity = currentQuantity + 1;

        if (size.getStock() < newQuantity) {
            throw new BusinessException(
                    CartError.INSUFFICIENT_STOCK,
                    "Sản phẩm '" + product.getName() + "' (Màu: " + color.getColorName() +
                            ", Size: " + size.getSizeName() + ") chỉ còn " +
                            size.getStock() + " sản phẩm trong kho. " +
                            "Bạn đang có " + currentQuantity + " sản phẩm trong giỏ."
            );
        }

        // 8️⃣ Tăng số lượng
        targetItem.setQuantity(newQuantity);

        // 9️⃣ Cập nhật tổng giá trị cart
        BigDecimal total = cart.getItems().stream()
                .map(i -> i.getPrice().multiply(BigDecimal.valueOf(i.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        cart.setTotalAmount(total);

        // 🔟 Cập nhật thời gian
        cart.setUpdatedAt(Instant.now());

        // 1️⃣1️⃣ Lưu thay đổi
        iRepositoryCart.save(cart);
    }
}
