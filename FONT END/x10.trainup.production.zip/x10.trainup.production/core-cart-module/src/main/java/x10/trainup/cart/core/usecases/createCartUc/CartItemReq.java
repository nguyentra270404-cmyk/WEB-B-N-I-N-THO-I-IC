package x10.trainup.cart.core.usecases.createCartUc;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CartItemReq {

    @NotBlank(message = "ProductId không được để trống")
    private String productId;

    @NotBlank(message = "Tên sản phẩm không được để trống")
    private String productName;

    @NotBlank(message = "ColorId không được để trống")
    private String colorId;

    private String colorName;   // optional, BE có thể override từ DB

    @NotBlank(message = "SizeId không được để trống")
    private String sizeId;

    private String sizeName;    // optional, BE có thể override từ DB

    @NotNull(message = "Giá sản phẩm không được để trống")
    private BigDecimal price;   // BE sẽ ưu tiên lấy theo size (discountPrice/price)

    @Min(value = 1, message = "Số lượng tối thiểu là 1")
    private int quantity;

    private String imageUrl;    // Ảnh hiển thị trên cart (thường là ảnh theo màu)
}
