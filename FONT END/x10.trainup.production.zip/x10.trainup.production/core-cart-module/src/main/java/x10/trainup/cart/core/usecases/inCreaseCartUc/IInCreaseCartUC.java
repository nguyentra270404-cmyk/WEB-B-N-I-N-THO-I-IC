package x10.trainup.cart.core.usecases.inCreaseCartUc;

public interface IInCreaseCartUC {

    void increase(IncreaseCartReq req,String userId);
}
