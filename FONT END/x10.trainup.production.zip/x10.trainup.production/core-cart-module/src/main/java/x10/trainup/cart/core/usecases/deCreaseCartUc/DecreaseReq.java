package x10.trainup.cart.core.usecases.deCreaseCartUc;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DecreaseReq {

    private String productId;  // ID sản phẩm
    private String colorId;    // ID màu
    private String sizeId;     // ID size (dung lượng)
}
