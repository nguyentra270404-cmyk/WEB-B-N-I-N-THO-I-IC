package x10.trainup.cart.core.usecases.updateCartItemUc;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import x10.trainup.cart.core.error.CartError;
import x10.trainup.cart.core.repository.IRepositoryCart;
import x10.trainup.commons.domain.entities.CartEntity;
import x10.trainup.commons.domain.entities.CartItemEntity;
import x10.trainup.commons.domain.entities.ColorVariantEntity;
import x10.trainup.commons.domain.entities.ProductEntity;
import x10.trainup.commons.domain.entities.SizeVariantEntity;
import x10.trainup.commons.exceptions.BusinessException;
import x10.trainup.product.core.repositories.IRepositoryProduct;
import x10.trainup.user.core.usecases.ICoreUserSerivce;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class UpdateQuantityUcImpl implements IUpdateQuantityUc {

    private final IRepositoryCart iRepositoryCart;
    private final ICoreUserSerivce iCoreUserSerivce;
    private final IRepositoryProduct iRepositoryProduct;

    @Override
    public void execute(UpdateQuantityReq req, String userId) {
        // 1️⃣ Validate user tồn tại
        if (!iCoreUserSerivce.existsById(userId)) {
            throw new BusinessException(
                    CartError.USER_NOT_FOUND,
                    "Không tìm thấy người dùng với id: " + userId
            );
        }

        // 2️⃣ Tìm giỏ hàng của user
        Optional<CartEntity> cartOptional = iRepositoryCart.findByUserId(userId);

        if (cartOptional.isEmpty()) {
            throw new BusinessException(
                    CartError.CART_NOT_FOUND,
                    "Không tìm thấy giỏ hàng của người dùng: " + userId
            );
        }

        CartEntity cart = cartOptional.get();

        // 3️⃣ Kiểm tra giỏ hàng có rỗng không
        if (cart.getItems() == null || cart.getItems().isEmpty()) {
            throw new BusinessException(
                    CartError.CART_IS_EMPTY,
                    "Giỏ hàng trống, không có sản phẩm để cập nhật"
            );
        }

        // 4️⃣ Tìm item cần cập nhật (productId + colorId + sizeId)
        CartItemEntity itemToUpdate = cart.getItems().stream()
                .filter(item -> isMatchingItem(item, req))
                .findFirst()
                .orElseThrow(() -> new BusinessException(
                        CartError.ITEM_NOT_FOUND,
                        String.format(
                                "Không tìm thấy sản phẩm trong giỏ hàng: productId=%s, colorId=%s, sizeId=%s",
                                req.getProductId(), req.getColorId(), req.getSizeId()
                        )
                ));

        // 5️⃣ Lấy thông tin product từ DB để check stock
        ProductEntity product = iRepositoryProduct.findById(req.getProductId())
                .orElseThrow(() -> new BusinessException(
                        CartError.PRODUCT_NOT_FOUND,
                        "ProductId: " + req.getProductId() + " không tồn tại.")
                );

        // 6️⃣ Tìm color trong product
        ColorVariantEntity color = Optional.ofNullable(product.getColors())
                .orElse(List.of())
                .stream()
                .filter(c -> c.getId() != null && c.getId().equals(req.getColorId()))
                .findFirst()
                .orElseThrow(() -> new BusinessException(
                        CartError.COLOR_NOT_FOUND,
                        "Không tìm thấy màu với id: " + req.getColorId()
                ));

        // 7️⃣ Tìm size trong color
        SizeVariantEntity size = Optional.ofNullable(color.getSizes())
                .orElse(List.of())
                .stream()
                .filter(s -> s.getId() != null && s.getId().equals(req.getSizeId()))
                .findFirst()
                .orElseThrow(() -> new BusinessException(
                        CartError.SIZE_NOT_FOUND,
                        "Không tìm thấy size với id: " + req.getSizeId()
                ));

        // 8️⃣ Kiểm tra tồn kho: quantity mới không được vượt quá stock
        int quantityInStock = size.getStock();
        if (req.getQuantity() > quantityInStock) {
            throw new BusinessException(
                    CartError.INSUFFICIENT_STOCK,
                    "Sản phẩm '" + product.getName() + "' (Màu: " + color.getColorName()
                            + ", Size: " + size.getSizeName() + ") chỉ còn "
                            + quantityInStock + " sản phẩm trong kho. "
                            + "Không thể cập nhật số lượng thành " + req.getQuantity() + "."
            );
        }

        // 9️⃣ Cập nhật số lượng mới
        itemToUpdate.setQuantity(req.getQuantity());

        // 🔟 Tính lại tổng tiền
        BigDecimal newTotalAmount = cart.getItems().stream()
                .map(item -> item.getPrice().multiply(BigDecimal.valueOf(item.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        cart.setTotalAmount(newTotalAmount);
        cart.setUpdatedAt(Instant.now());

        // 1️⃣1️⃣ Lưu vào database
        iRepositoryCart.save(cart);
    }

    /**
     * Kiểm tra item có khớp với điều kiện update không:
     *  productId + colorId + sizeId
     */
    private boolean isMatchingItem(CartItemEntity item, UpdateQuantityReq req) {
        return item.getProductId().equals(req.getProductId())
                && item.getColorId().equals(req.getColorId())
                && item.getSizeId().equals(req.getSizeId());
    }
}
