package x10.trainup.cart.core.usecases.inCreaseCartUc;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@Builder
@NoArgsConstructor
public class IncreaseCartReq {

    @NotBlank(message = "ProductId không được để trống")
    private String productId;

    @NotBlank(message = "ColorId không được để trống")
    private String colorId;

    @NotBlank(message = "SizeId không được để trống")
    private String sizeId;   // Bắt buộc luôn có size/dung lượng
}
