package x10.trainup.cart.core.usecases.removeItemUc;

public interface IRemoveItemUc {
    void execute(RemoveItemReq req,String userId);
}