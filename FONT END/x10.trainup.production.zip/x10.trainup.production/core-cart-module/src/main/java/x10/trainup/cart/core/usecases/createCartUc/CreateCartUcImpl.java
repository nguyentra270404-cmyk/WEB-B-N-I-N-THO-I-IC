package x10.trainup.cart.core.usecases.createCartUc;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import x10.trainup.cart.core.error.CartError;
import x10.trainup.cart.core.repository.IRepositoryCart;
import x10.trainup.commons.domain.entities.CartEntity;
import x10.trainup.commons.domain.entities.CartItemEntity;
import x10.trainup.commons.domain.entities.ColorVariantEntity;
import x10.trainup.commons.domain.entities.ProductEntity;
import x10.trainup.commons.domain.entities.SizeVariantEntity;
import x10.trainup.commons.exceptions.BusinessException;
import x10.trainup.product.core.repositories.IRepositoryProduct;
import x10.trainup.user.core.errors.UserError;
import x10.trainup.user.core.usecases.ICoreUserSerivce;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class CreateCartUcImpl implements ICreateCartUc {

    private final ICoreUserSerivce iCoreUserSerivce;
    private final IRepositoryCart iRepositoryCart;
    private final IRepositoryProduct iRepositoryProduct;

    @Override
    public CreateCartRes addToCart(CreateCartReq req, String userId) {

        // 1. Check user tồn tại
        if (!iCoreUserSerivce.existsById(userId)) {
            throw new BusinessException(UserError.USER_NOT_FOUND, "Không tìm thấy người dùng.");
        }

        // 2. Lấy cart hiện tại hoặc tạo mới
        Optional<CartEntity> optionalCart = iRepositoryCart.findByUserId(userId);
        CartEntity cart = optionalCart.orElseGet(() -> CartEntity.builder()
                .userId(userId)
                .items(new ArrayList<>())
                .totalAmount(BigDecimal.ZERO)
                .createdAt(Instant.now())
                .updatedAt(Instant.now())
                .build()
        );

        // 3. Xử lý từng item
        for (CartItemReq itemReq : req.getItems()) {

            // 3.1 Validate product tồn tại
            ProductEntity product = iRepositoryProduct.findById(itemReq.getProductId())
                    .orElseThrow(() -> new BusinessException(
                            CartError.PRODUCT_NOT_FOUND,
                            "ProductId: " + itemReq.getProductId() + " không tồn tại.")
                    );

            // 3.2 Tìm color trong product
            ColorVariantEntity color = Optional.ofNullable(product.getColors())
                    .orElse(List.of())
                    .stream()
                    .filter(c -> c.getId() != null && c.getId().equals(itemReq.getColorId()))
                    .findFirst()
                    .orElseThrow(() -> new BusinessException(
                            CartError.CART_NOT_FOUND,
                            "ColorId: " + itemReq.getColorId() + " không tồn tại trong product: " + itemReq.getProductId())
                    );

            // 3.3 Tìm size trong color
            SizeVariantEntity size = Optional.ofNullable(color.getSizes())
                    .orElse(List.of())
                    .stream()
                    .filter(s -> s.getId() != null && s.getId().equals(itemReq.getSizeId()))
                    .findFirst()
                    .orElseThrow(() -> new BusinessException(
                            CartError.SIZE_NOT_FOUND,
                            "SizeId: " + itemReq.getSizeId() + " không tồn tại trong color: " + itemReq.getColorId())
                    );

            // 3.4 Xác định giá thực tế (ưu tiên discountPrice)
            BigDecimal actualPrice =
                    (size.getDiscountPrice() != null && size.getDiscountPrice().compareTo(BigDecimal.ZERO) > 0)
                            ? size.getDiscountPrice()
                            : size.getPrice();

            if (actualPrice == null) {
                throw new BusinessException(
                        CartError.PRICE_NOT_FOUND,
                        "Không tìm thấy giá cho sizeId: " + itemReq.getSizeId()
                );
            }

            // 3.5 Validate tồn kho: không cho vượt quá size.stock
            int requestedQuantity = itemReq.getQuantity();

            // Cộng thêm số lượng đã có sẵn trong cart (nếu cùng product+color+size)
            int existingQuantityInCart = cart.getItems().stream()
                    .filter(i -> i.getProductId().equals(itemReq.getProductId())
                            && itemReq.getColorId().equals(i.getColorId())
                            && itemReq.getSizeId().equals(i.getSizeId()))
                    .mapToInt(CartItemEntity::getQuantity)
                    .sum();

            int totalRequestedQuantity = requestedQuantity + existingQuantityInCart;

            if (size.getStock() < totalRequestedQuantity) {
                throw new BusinessException(
                        CartError.INSUFFICIENT_STOCK,
                        "Sản phẩm '" + product.getName() + "' (Màu: " + color.getColorName() +
                                ", Size: " + size.getSizeName() + ") chỉ còn " +
                                size.getStock() + " sản phẩm trong kho."
                );
            }

            // 3.6 Nếu item đã tồn tại trong cart → cộng quantity
            boolean itemExists = false;
            for (CartItemEntity item : cart.getItems()) {
                if (item.getProductId().equals(itemReq.getProductId())
                        && itemReq.getColorId().equals(item.getColorId())
                        && itemReq.getSizeId().equals(item.getSizeId())) {

                    item.setQuantity(item.getQuantity() + itemReq.getQuantity());
                    itemExists = true;
                    break;
                }
            }

            // 3.7 Item mới → thêm vào cart
            if (!itemExists) {
                CartItemEntity newItem = CartItemEntity.builder()
                        .productId(itemReq.getProductId())
                        .productName(product.getName())             // snapshot từ DB
                        .colorId(color.getId())
                        .colorName(color.getColorName())
                        .sizeId(size.getId())
                        .sizeName(size.getSizeName())
                        .price(actualPrice)
                        .quantity(itemReq.getQuantity())
                        .imageUrl(itemReq.getImageUrl() != null ? itemReq.getImageUrl() : color.getMainImage())
                        .build();

                cart.getItems().add(newItem);
            }
        }

        // 4. Cập nhật tổng tiền
        BigDecimal total = cart.getItems().stream()
                .map(i -> i.getPrice().multiply(BigDecimal.valueOf(i.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        cart.setTotalAmount(total);
        cart.setUpdatedAt(Instant.now());

        CartEntity savedCart = iRepositoryCart.save(cart);

        // 5. Build response
        List<CreateCartRes.CartItemRes> itemsRes = new ArrayList<>();
        for (CartItemEntity item : savedCart.getItems()) {
            itemsRes.add(CreateCartRes.CartItemRes.builder()
                    .productId(item.getProductId())
                    .productName(item.getProductName())
                    .colorId(item.getColorId())
                    .colorName(item.getColorName())
                    .sizeId(item.getSizeId())
                    .sizeName(item.getSizeName())
                    .price(item.getPrice())
                    .quantity(item.getQuantity())
                    .imageUrl(item.getImageUrl())
                    .build());
        }

        return CreateCartRes.builder()
                .cartId(savedCart.getId())
                .userId(savedCart.getUserId())
                .items(itemsRes)
                .totalAmount(savedCart.getTotalAmount())
                .createdAt(savedCart.getCreatedAt())
                .updatedAt(savedCart.getUpdatedAt())
                .build();
    }
}
