package x10.trainup.order.core.usecases.updateOrderStatusUc;

public interface IUpdateOrderStatus {
    void process(UpdateOrderStatusReq req);
}
