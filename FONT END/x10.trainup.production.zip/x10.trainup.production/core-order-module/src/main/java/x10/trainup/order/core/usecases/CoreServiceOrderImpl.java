package x10.trainup.order.core.usecases;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import x10.trainup.commons.domain.entities.OrderEntity;
import x10.trainup.order.core.repositories.IOrderRepository;
import x10.trainup.order.core.usecases.cancelOrder.CancelOrderReq;
import x10.trainup.order.core.usecases.cancelOrder.ICancelOrderUc;
import x10.trainup.order.core.usecases.createOrder.CreateOrderReq;
import x10.trainup.order.core.usecases.createOrder.ICreateOrderUc;
import x10.trainup.order.core.usecases.updateOrderStatusUc.IUpdateOrderStatus;
import x10.trainup.order.core.usecases.updateOrderStatusUc.UpdateOrderStatusReq;

import java.util.List;


@AllArgsConstructor
@Service
public class CoreServiceOrderImpl implements ICoreOrderService {

    private final ICreateOrderUc iCreateOrderUc;
    private final IOrderRepository iOrderRepository;
    private final IUpdateOrderStatus iUpdateOrderStatus;
    private final ICancelOrderUc iCancelOrderUc;

    @Override
    public void cancelOrder(CancelOrderReq req){
        iCancelOrderUc.process(req);
    }
    @Override
    public OrderEntity createOrder(CreateOrderReq req) {
        return iCreateOrderUc.process(req);
    }
    @Override
    public List<OrderEntity> getAllOrdersSortedByDateDesc() {
        return iOrderRepository.findAllOrderByCreatedAtDesc();
    }

    @Override
    public List<OrderEntity> getOrdersByUserId(String userId) {
        return iOrderRepository.findByUserId(userId);
    }

    @Override
    public void updateOrderStatus(UpdateOrderStatusReq req){
    	iUpdateOrderStatus.process(req);
    }



}
