package x10.trainup.order.core.usecases;

import x10.trainup.commons.domain.entities.OrderEntity;
import x10.trainup.order.core.usecases.cancelOrder.CancelOrderReq;
import x10.trainup.order.core.usecases.createOrder.CreateOrderReq;
import x10.trainup.order.core.usecases.updateOrderStatusUc.UpdateOrderStatusReq;

import java.util.List;


public interface ICoreOrderService {
    OrderEntity createOrder(CreateOrderReq req);
    List<OrderEntity> getAllOrdersSortedByDateDesc();
    List<OrderEntity> getOrdersByUserId(String userId);
    void updateOrderStatus(UpdateOrderStatusReq req);

    void cancelOrder(CancelOrderReq req);


}