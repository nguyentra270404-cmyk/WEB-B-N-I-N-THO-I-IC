package x10.trainup.order.core.usecases.updateOrderStatusUc;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import x10.trainup.commons.domain.entities.OrderEntity;
import x10.trainup.commons.domain.entities.OrderItemEntity;
import x10.trainup.commons.domain.enums.OrderStatus;
import x10.trainup.commons.exceptions.BusinessException;
import x10.trainup.order.core.errors.OrderError;
import x10.trainup.order.core.repositories.IOrderRepository;
import x10.trainup.product.core.usecases.ICoreProductService;
import x10.trainup.product.core.usecases.increaseStockAndDecreaseSoldUc.StockUpdateItem;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
@AllArgsConstructor
public class UpdateOrderStatusImpl implements IUpdateOrderStatus {

    private final IOrderRepository iOrderRepository;
    private final ICoreProductService iCoreProductService;

    // Các trạng thái chuyển đổi hợp lệ
    private static final Set<OrderStatus> PENDING_VALID_TRANSITIONS = Set.of(
            OrderStatus.CONFIRMED,
            OrderStatus.CANCELLED
    );

    private static final Set<OrderStatus> CONFIRMED_VALID_TRANSITIONS = Set.of(
            OrderStatus.CANCELLED
    );

    @Override
    @Transactional
    public void process(UpdateOrderStatusReq req) {
        log.info("Processing update order status for orderId: {}, newStatus: {}",
                req.getOrderId(), req.getNewStatus());

        // 1. Validate input
        validateRequest(req);

        // 2. Tìm order
        Optional<OrderEntity> orderOpt = iOrderRepository.findById(req.getOrderId());
        if (orderOpt.isEmpty()) {
            throw new BusinessException(
                    OrderError.ORDER_NOT_FOUND,
                    "Không tìm thấy đơn hàng với ID: " + req.getOrderId()
            );
        }

        OrderEntity order = orderOpt.get();
        OrderStatus oldStatus = order.getStatus();
        OrderStatus newStatus = req.getNewStatus();

        // 3. Validate status transition
        validateStatusTransition(oldStatus, newStatus);

        // 4. Xử lý logic stock theo status transition
        handleStockUpdate(order, oldStatus, newStatus);

        // 5. Update order
        order.setStatus(newStatus);
        order.setUpdatedAt(Instant.now());

        // 6. Cập nhật note nếu có
        if (req.getNote() != null && !req.getNote().isBlank()) {
            appendNoteToOrder(order, newStatus, req.getNote());
        }

        // 7. Save
        iOrderRepository.save(order);

        log.info("Order status updated successfully. OrderId: {}, {} -> {}",
                req.getOrderId(), oldStatus, newStatus);
    }

    // ====================================================
    // 🔹 Xử lý cập nhật stock dựa trên status transition
    // ====================================================
    private void handleStockUpdate(OrderEntity order, OrderStatus oldStatus, OrderStatus newStatus) {
        List<StockUpdateItem> stockItems = convertOrderItemsToStockItems(order.getItems());

        if (stockItems.isEmpty()) {
            log.info("Order {} has no items. Skip stock update.", order.getId());
            return;
        }

        // Case 1: PENDING -> CONFIRMED: Trừ stock, tăng sold
        if (oldStatus == OrderStatus.PENDING && newStatus == OrderStatus.CONFIRMED) {
            log.info("Order transition PENDING -> CONFIRMED: Decreasing stock and increasing sold");
            try {
                iCoreProductService.decreaseStockAndIncreaseSold(stockItems);
                log.info("Stock decreased successfully for order: {}", order.getId());
            } catch (BusinessException e) {
                log.error("Failed to decrease stock for order {}: {}", order.getId(), e.getMessage());
                throw e; // rollback transaction
            }
        }

        // Case 2: CONFIRMED -> CANCELLED: Hoàn lại stock, giảm sold
        else if (oldStatus == OrderStatus.CONFIRMED && newStatus == OrderStatus.CANCELLED) {
            log.info("Order transition CONFIRMED -> CANCELLED: Increasing stock and decreasing sold (ROLLBACK)");
            try {
                iCoreProductService.increaseStockAndDecreaseSold(stockItems);
                log.info("Stock rollback completed successfully for order: {}", order.getId());
            } catch (BusinessException e) {
                log.error("Failed to rollback stock for order {}: {}", order.getId(), e.getMessage());
                throw e; // rollback transaction
            }
        }

        // Case 3: PENDING -> CANCELLED: Không cần cập nhật stock (chưa trừ)
        else if (oldStatus == OrderStatus.PENDING && newStatus == OrderStatus.CANCELLED) {
            log.info("Order transition PENDING -> CANCELLED: No stock update needed (order was not confirmed)");
        }

        // Các case khác (do validate đã chặn nên thường không tới đây)
        else {
            log.debug("No stock update required for transition {} -> {}", oldStatus, newStatus);
        }
    }

    // ====================================================
    // 🔹 Convert OrderItemEntity -> StockUpdateItem (dt)
    // ====================================================
    private List<StockUpdateItem> convertOrderItemsToStockItems(List<OrderItemEntity> items) {
        if (items == null || items.isEmpty()) {
            log.warn("Order has no items to convert for stock update");
            return List.of();
        }

        return items.stream()
                .map(item -> {
                    log.debug("Converting order item: productId={}, colorId={}, sizeId={}, quantity={}",
                            item.getProductId(), item.getColorId(), item.getSizeId(), item.getQuantity());

                    return StockUpdateItem.builder()
                            .productId(item.getProductId())
                            .colorId(item.getColorId())
                            .sizeId(item.getSizeId())
                            .quantity(item.getQuantity())
                            .build();
                })
                .collect(Collectors.toList());
    }

    // ====================================================
    // 🔹 Validate input
    // ====================================================
    private void validateRequest(UpdateOrderStatusReq req) {
        if (req.getOrderId() == null || req.getOrderId().isBlank()) {
            throw new BusinessException(
                    OrderError.INVALID_ORDER_ITEM,
                    "Order ID không được để trống"
            );
        }
        if (req.getNewStatus() == null) {
            throw new BusinessException(
                    OrderError.INVALID_ORDER_ITEM,
                    "Trạng thái mới không được để trống"
            );
        }
    }

    // ====================================================
    // 🔹 Validate chuyển trạng thái
    // ====================================================
    private void validateStatusTransition(OrderStatus from, OrderStatus to) {
        // Không cho set lại trạng thái giống nhau
        if (from == to) {
            throw new BusinessException(
                    OrderError.INVALID_STATUS_TRANSITION,
                    String.format("Đơn hàng đã ở trạng thái %s", to)
            );
        }

        // Không cho đổi trạng thái từ CANCELLED
        if (from == OrderStatus.CANCELLED) {
            throw new BusinessException(
                    OrderError.INVALID_STATUS_TRANSITION,
                    "Không thể thay đổi trạng thái của đơn hàng đã hủy"
            );
        }

        switch (from) {
            case PENDING:
                if (!PENDING_VALID_TRANSITIONS.contains(to)) {
                    throw new BusinessException(
                            OrderError.INVALID_STATUS_TRANSITION,
                            String.format("Không thể chuyển từ %s sang %s. Chỉ có thể chuyển sang: %s",
                                    from, to, PENDING_VALID_TRANSITIONS)
                    );
                }
                break;

            case CONFIRMED:
                if (!CONFIRMED_VALID_TRANSITIONS.contains(to)) {
                    throw new BusinessException(
                            OrderError.INVALID_STATUS_TRANSITION,
                            String.format("Không thể chuyển từ %s sang %s. Chỉ có thể chuyển sang: %s",
                                    from, to, CONFIRMED_VALID_TRANSITIONS)
                    );
                }
                break;

            default:
                throw new BusinessException(
                        OrderError.INVALID_STATUS_TRANSITION,
                        String.format("Trạng thái %s không hợp lệ", from)
                );
        }
    }

    // ====================================================
    // 🔹 Ghi note vào order
    // ====================================================
    private void appendNoteToOrder(OrderEntity order, OrderStatus newStatus, String note) {
        String currentNote = order.getNote() != null ? order.getNote() : "";
        String timestamp = Instant.now().toString();
        String newNote = String.format("%s\n[%s - %s] %s", currentNote, timestamp, newStatus, note);
        order.setNote(newNote.trim());
    }
}
