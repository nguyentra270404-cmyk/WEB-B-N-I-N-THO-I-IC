package x10.trainup.order.core.usecases.createOrder;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import x10.trainup.commons.domain.entities.*;
import x10.trainup.commons.domain.enums.OrderStatus;
import x10.trainup.commons.domain.enums.PaymentStatus;
import x10.trainup.commons.exceptions.BusinessException;
import x10.trainup.discord.service.usecase.DiscordServiceUc;
import x10.trainup.order.core.errors.OrderError;
import x10.trainup.order.core.repositories.IOrderRepository;
import x10.trainup.product.core.repositories.IRepositoryProduct;
import x10.trainup.user.core.usecases.ICoreUserSerivce;
import x10.trainup.user.core.usecases.createGuestUserUc.CreateGuestUserReq;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.*;

@Service
@AllArgsConstructor
@Slf4j
public class CreateOrderUcImpl implements ICreateOrderUc {

    private final IOrderRepository iOrderRepository;
    private final ICoreUserSerivce iCoreUserSerivce;
    private final IRepositoryProduct iRepositoryProduct;
    private final DiscordServiceUc discordServiceUc;

    // (nếu dùng GHN / GHTK thì sau này em gắn lại, giờ không dùng tới)
    private static final int DEFAULT_FROM_DISTRICT_ID = 1455;
    private static final String DEFAULT_FROM_WARD_CODE = "21408";
    private static final int DEFAULT_SERVICE_TYPE_ID = 2;

    @Override
    public OrderEntity process(CreateOrderReq req) {
        // 1. Lấy user hoặc tạo guest user
        UserEntity user = getOrCreateGuestUser(req);

        // 2. Build danh sách item theo domain mới Product → Color → Size
        List<OrderItemEntity> orderItems = buildOrderItems(req.getItems());

        // 3. Tính tiền
        BigDecimal subtotal = calculateSubtotal(orderItems);
        BigDecimal shippingFee = req.getShippingFee();
        BigDecimal totalAmount = subtotal.add(shippingFee);

        // 4. Địa chỉ giao hàng
        ShippingAddressEntity shippingAddress = buildShippingAddress(req.getShippingAddress());

        // 5. Xác định paymentStatus cuối cùng
        PaymentStatus finalPaymentStatus =
                (req.getPaymentStatus() != null) ? req.getPaymentStatus() : PaymentStatus.UNPAID;

        // 6. Tạo order entity
        OrderEntity order = OrderEntity.builder()
                .id(UUID.randomUUID().toString())
                .orderNumber(generateOrderNumber())
                .userId(user.getId())
                .status(OrderStatus.PENDING)
                .paymentStatus(finalPaymentStatus)
                .paymentMethod(req.getPaymentMethod())
                .items(orderItems)
                .subtotal(subtotal)
                .shippingFee(shippingFee)
                .totalAmount(totalAmount)
                .shippingAddress(shippingAddress)
                .note(req.getNote())
                .createdAt(Instant.now())
                .updatedAt(Instant.now())
                .build();

        OrderEntity saved = iOrderRepository.save(order);

        // 7. Gửi thông báo lên Discord (nếu lỗi thì không phá flow)
        try {
            discordServiceUc.sendNewOrderMessage(saved);
        } catch (Exception e) {
            log.error("Lỗi gửi Discord webhook cho order {}", saved.getOrderNumber(), e);
        }

        return saved;
    }

    // ====================================================
    // 🔹 Lấy user hoặc tạo guest user
    // ====================================================

    private UserEntity getOrCreateGuestUser(CreateOrderReq req) {
        if (req.getUserId() != null) {
            Optional<UserEntity> existingUser = iCoreUserSerivce.getUserById(req.getUserId());
            if (existingUser.isPresent()) {
                return existingUser.get();
            }
        }

        ShippingAddressReq ship = req.getShippingAddress();

        CreateGuestUserReq guestReq = CreateGuestUserReq.builder()
                .recipientName(ship.getRecipientName())
                .phone(ship.getPhoneNumber())
                .email(ship.getEmail())
                .street(ship.getAddress())
                .ward(ship.getWard())
                .district(ship.getDistrict())
                .province(ship.getCity())
                .country("Vietnam")
                .wardCode(ship.getWardCode())
                .provinceId(ship.getProvinceId())
                .districtId(ship.getDistrictId())
                .build();

        return iCoreUserSerivce.createGuestUser(guestReq);
    }

    // ====================================================
    // 🔹 Build OrderItemEntity (domain mới: product + color + size)
    // ====================================================

    private List<OrderItemEntity> buildOrderItems(List<OrderItemReq> itemsReq) {
        List<OrderItemEntity> orderItems = new ArrayList<>();

        for (OrderItemReq itemReq : itemsReq) {
            // 1. Validate product tồn tại
            ProductEntity product = iRepositoryProduct.findById(itemReq.getProductId())
                    .orElseThrow(() -> new BusinessException(
                            OrderError.INVALID_ORDER_ITEM,
                            "Product not found: " + itemReq.getProductId(),
                            Map.of("productId", itemReq.getProductId())
                    ));

            // 2. Tìm color trong product
            ColorVariantEntity color = Optional.ofNullable(product.getColors())
                    .orElse(List.of())
                    .stream()
                    .filter(c -> c.getId() != null && c.getId().equals(itemReq.getColorId()))
                    .findFirst()
                    .orElseThrow(() -> new BusinessException(
                            OrderError.INVALID_ORDER_ITEM,
                            "Color not found for product: " + itemReq.getProductId(),
                            Map.of(
                                    "productId", itemReq.getProductId(),
                                    "colorId", itemReq.getColorId()
                            )
                    ));

            // 3. Tìm size trong color
            SizeVariantEntity size = Optional.ofNullable(color.getSizes())
                    .orElse(List.of())
                    .stream()
                    .filter(s -> s.getId() != null && s.getId().equals(itemReq.getSizeId()))
                    .findFirst()
                    .orElseThrow(() -> new BusinessException(
                            OrderError.INVALID_ORDER_ITEM,
                            "Size not found for product/color",
                            Map.of(
                                    "productId", itemReq.getProductId(),
                                    "colorId", itemReq.getColorId(),
                                    "sizeId", itemReq.getSizeId()
                            )
                    ));

            // 4. Lấy giá theo size (ưu tiên discountPrice > 0, nếu không dùng price)
            BigDecimal unitPrice =
                    (size.getDiscountPrice() != null && size.getDiscountPrice().compareTo(BigDecimal.ZERO) > 0)
                            ? size.getDiscountPrice()
                            : size.getPrice();

            BigDecimal subtotal = unitPrice.multiply(BigDecimal.valueOf(itemReq.getQuantity()));

            // 5. Build OrderItemEntity mới (snapshot theo thời điểm đặt)
            OrderItemEntity orderItem = OrderItemEntity.builder()
                    .productId(product.getId())
                    .productName(product.getName())
                    .colorId(color.getId())
                    .colorName(color.getColorName())
                    .mainImage(color.getMainImage())
                    .sizeId(size.getId())
                    .sizeName(size.getSizeName())
                    .price(unitPrice)
                    .quantity(itemReq.getQuantity())
                    .subtotal(subtotal)
                    .build();

            orderItems.add(orderItem);
        }

        return orderItems;
    }

    // ====================================================
    // 🔹 Tính subtotal
    // ====================================================

    private BigDecimal calculateSubtotal(List<OrderItemEntity> items) {
        return items.stream()
                .map(OrderItemEntity::getSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    // ====================================================
    // 🔹 Build ShippingAddress
    // ====================================================

    private ShippingAddressEntity buildShippingAddress(ShippingAddressReq req) {
        return ShippingAddressEntity.builder()
                .recipientName(req.getRecipientName())
                .phoneNumber(req.getPhoneNumber())
                .address(req.getAddress())
                .ward(req.getWard())
                .district(req.getDistrict())
                .city(req.getCity())
                .districtId(req.getDistrictId())
                .provinceId(req.getProvinceId())
                .wardCode(req.getWardCode())
                .country("Việt Nam")
                .build();
    }

    // ====================================================
    // 🔹 Generate order number
    // ====================================================

    private String generateOrderNumber() {
        String dateStr = Instant.now().toString().substring(0, 10).replace("-", "");
        String randomSuffix = String.format("%03d", (int) (Math.random() * 1000));
        return "ORD-" + dateStr + "-" + randomSuffix;
    }
}
