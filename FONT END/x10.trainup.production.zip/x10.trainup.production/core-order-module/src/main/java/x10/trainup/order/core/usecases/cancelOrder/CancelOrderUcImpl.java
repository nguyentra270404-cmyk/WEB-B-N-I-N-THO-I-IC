package x10.trainup.order.core.usecases.cancelOrder;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import x10.trainup.commons.domain.entities.OrderEntity;
import x10.trainup.commons.domain.enums.OrderStatus;
import x10.trainup.commons.exceptions.BusinessException;
import x10.trainup.order.core.errors.OrderError;
import x10.trainup.order.core.repositories.IOrderRepository;

import java.time.Instant;
import java.util.Optional;

@Service
@AllArgsConstructor
public class CancelOrderUcImpl implements ICancelOrderUc {

    private final IOrderRepository iOrderRepository;

    @Override
    @Transactional
    public void process(CancelOrderReq req) {
        // 1. Validate input
        validateRequest(req);

        // 2. Tìm order
        Optional<OrderEntity> orderOpt = iOrderRepository.findById(req.getOrderId());

        if (orderOpt.isEmpty()) {
            throw new BusinessException(OrderError.ORDER_NOT_FOUND,
                    "Không tìm thấy đơn hàng với ID: " + req.getOrderId());
        }

        OrderEntity order = orderOpt.get();

        // 3. Verify ownership
        if (!order.getUserId().equals(req.getUserId())) {
            throw new BusinessException(OrderError.ORDER_NOT_FOUND,
                    "Không tìm thấy đơn hàng với ID: " + req.getOrderId());
        }

        // 4. Check if can cancel
        if (order.getStatus() != OrderStatus.PENDING) {
            throw new BusinessException(OrderError.ORDER_CANNOT_BE_CANCELLED,
                    "Chỉ có thể hủy đơn hàng ở trạng thái PENDING. Trạng thái hiện tại: " + order.getStatus());
        }

        // 5. Update order status to CANCELLED
        order.setStatus(OrderStatus.CANCELLED);
        order.setUpdatedAt(Instant.now());

        // 6. Save
        iOrderRepository.save(order);

    }

    /**
     * Validate request input
     */
    private void validateRequest(CancelOrderReq req) {
        if (req.getOrderId() == null || req.getOrderId().isBlank()) {
            throw new BusinessException(OrderError.INVALID_ORDER_ITEM,
                    "Order ID không được để trống");
        }
        if (req.getUserId() == null || req.getUserId().isBlank()) {
            throw new BusinessException(OrderError.INVALID_ORDER_ITEM,
                    "User ID không được để trống");
        }
    }
}