package x10.trainup.order.core.usecases.cancelOrder;


public interface ICancelOrderUc {
    void process(CancelOrderReq req);
}