package x10.trainup.order.core.usecases.updateOrderStatusUc;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import x10.trainup.commons.domain.enums.OrderStatus;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateOrderStatusReq {
    @NotBlank(message = "Order ID không được để trống")
    private String orderId;

    @NotNull(message = "Trạng thái mới không được để trống")
    private OrderStatus newStatus;
    private String note; // Ghi chú lý do (optional)
}